package centralnode;

import model.UpdateMessage;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;

public class ClockServerThread extends Thread {

    private DatagramSocket syncSocket;

    private Map<InetAddress, Long> offsetMap = new HashMap<>(); // maps client IP addresses to clock offsets

    public ClockServerThread(DatagramSocket syncSocket) {
        this.syncSocket = syncSocket;
    }

    @Override
    public void run() {
        byte[] receiveData = new byte[1024];
        byte[] sendData;

        try {
            while (true) {
                // receive packet from middleNode
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                syncSocket.receive(receivePacket);

                // get client time and the server time
                long clientTime = ByteBuffer.wrap(receivePacket.getData()).getLong();
                long serverTime = System.currentTimeMillis();
                long rtt = serverTime - clientTime;

                // calculate clock offset
                InetAddress clientAddress = receivePacket.getAddress();
                Long offset = offsetMap.get(clientAddress);
                if (offset == null) {
                    offset = 0L;
                }
                offset = (offset + (clientTime - serverTime + rtt / 2)) / 2;
                offsetMap.put(clientAddress, offset);

                // send current time and clock offset to client
                sendData = ByteBuffer.allocate(8).putLong(serverTime + offset).array();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, receivePacket.getPort());
                syncSocket.send(sendPacket);

                // wait for next synchronization interval
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    // handle exception
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
