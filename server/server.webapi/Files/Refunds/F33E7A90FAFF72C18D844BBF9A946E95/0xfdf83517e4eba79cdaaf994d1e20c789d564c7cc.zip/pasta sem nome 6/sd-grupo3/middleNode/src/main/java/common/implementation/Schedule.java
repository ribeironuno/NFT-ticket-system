package common.implementation;


import common.interfaces.ISchedule;

//Implementation of schedule
public class Schedule implements ISchedule {

    private int hours;
    private int minutes;

    /**
     * @param hours   0 - 23  format
     * @param minutes 0 - 59 format
     * @throws IllegalArgumentException If it's a bad input from user.
     */
    public Schedule(int hours, int minutes) throws IllegalArgumentException {
        if (hours < 0 || hours > 23 || minutes < 0 || minutes > 60) {
            throw new IllegalArgumentException("Bad input");
        }
        this.hours = hours;
        this.minutes = minutes;
    }

    //gets hours
    public int getHours() {
        return hours;
    }

    //get minutes
    public int getMinutes() {
        return minutes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Schedule schedules = (Schedule) o;
        return hours == schedules.hours && minutes == schedules.minutes;
    }

    @Override
    public String toString() {
        return String.format("%02d:%02d", this.hours, this.minutes);
    }
}