package common.implementation;

import common.interfaces.IRequest;

import java.io.Serializable;

/**
 * Represents a request to be transfer between server and request
 */
public class Request implements IRequest, Comparable<Request>, Serializable {

    //the hash code of a client in order to middle node identify the client
    private int hashCodeSocketClient;
    //hash code of middle server to server identify which middle call
    private int hashCodeSocketMiddle;
    //port of middle node
    private int portMiddle;
    private RequestPriorityEnum priority;
    private String to;
    private RequestsEnum type;

    //object that will transport all information
    private Object content;
    //string message to be displayed
    private String message;

    public Request(int hashCodeSocket, int portMiddle, String to, RequestsEnum type, Object content) {
        //sets the priority
        switch (type) {
            case ADD_LINE, REPORT_FEEDBACK -> this.priority = RequestPriorityEnum.MEDIUM;

            case SUSPENDED_TRAFFIC, SCHEDULE_ALTERATION -> this.priority = RequestPriorityEnum.HIGH;

            default -> this.priority = RequestPriorityEnum.LOW;
        }
        this.hashCodeSocketClient = hashCodeSocket;
        this.portMiddle = portMiddle;
        this.to = to;
        this.type = type;
        this.content = content;
    }

    public void setHashCodeSocketClient(int hashCodeSocketClient) {
        this.hashCodeSocketClient = hashCodeSocketClient;
    }

    public void setHashCodeSocketMiddle(int hashCodeSocketMiddle) {
        this.hashCodeSocketMiddle = hashCodeSocketMiddle;
    }

    public void setPortMiddle(int portMiddle) {
        this.portMiddle = portMiddle;
    }

    public void setPriority(RequestPriorityEnum priority) {
        this.priority = priority;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public void setType(RequestsEnum type) {
        this.type = type;
    }

    public void setContent(Object content) {
        this.content = content;
    }

    public int getHashCodeSocketClient() {
        return hashCodeSocketClient;
    }

    public int getHashCodeSocketMiddle() {
        return hashCodeSocketMiddle;
    }

    public int getPortMiddle() {
        return portMiddle;
    }

    public RequestsEnum getType() {
        return type;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return this.message;
    }

    public Object getContent() {
        return this.content;
    }

    public String getTo() {
        return this.to;
    }

    public RequestPriorityEnum getPriority() {
        return this.priority;
    }

    @Override
    public int compareTo(Request o) {
        if (o.priority.ordinal() == this.priority.ordinal()) {
            return 0;
        } else {
            return o.priority.ordinal() - this.priority.ordinal();
        }
    }
}
