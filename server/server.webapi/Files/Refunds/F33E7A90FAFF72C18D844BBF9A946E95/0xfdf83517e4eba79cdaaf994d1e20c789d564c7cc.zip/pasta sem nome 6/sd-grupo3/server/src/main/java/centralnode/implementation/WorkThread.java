package centralnode.implementation;

import centralnode.model.User;
import common.implementation.*;
import common.interfaces.*;
import utils.Exporter;

import java.io.*;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Responsible to manage the request and send broadcast/multicast to all clients
 */
public class WorkThread extends Thread {
    //information about the server
    private ServerInformation serverInformation;
    private final Exporter exporter = new Exporter();
    //format of date
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    public WorkThread(ServerInformation serverInformation) {
        this.serverInformation = serverInformation;
    }

    @Override
    public void run() {
        while (true) {
            try {
                //for all requests in queue
                Request request = serverInformation.listOfRequests.get();
                if (request != null) {
                    this.handleRequest(request);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void handleRequest(Request request) throws IOException {
        String answer;
        String log = null;
        User user;
        Date date = new Date();
        try {
            serverInformation.middleNodeStatistics.get(request.getHashCodeSocketMiddle()).totalRequests++;
            serverInformation.totalRequests++;
            Request requestAnswer = request;

            switch (request.getType()) {

                case LOGIN:
                    Request.LoginInformation loginInfo = (Request.LoginInformation) request.getContent();
                    user = serverInformation.listOfUsers.get(loginInfo.getEmail());
                    //Passenger tried to log in with an account that is not registered
                    if (user == null) {
                        requestAnswer.setMessage("User is not registered!");
                    } else {
                        if (user.getPassword().equals(loginInfo.getPassword())) {
                            if (user.getRole() == RoleEnum.PASSENGER) {
                                List<Line> linesAssociated = new ArrayList<>();
                                //get lines associated
                                for (int i = 0; i < user.getLinesAssociated().size(); i++) {
                                    Line line = serverInformation.listOfLines.get(user.getLinesAssociated().get(i));
                                    if (line != null) {
                                        linesAssociated.add(line);
                                    }
                                }

                                requestAnswer.setContent(new Request.LinesEmail(linesAssociated, loginInfo.getEmail(), RoleEnum.PASSENGER));
                                requestAnswer.setMessage("Login successful!");
                                serverInformation.middleNodeStatistics.get(request.getHashCodeSocketMiddle()).totalClientsOnline++;

                            } else {
                                if (user.getRole() == RoleEnum.ADMIN) {
                                    serverInformation.middleNodeStatistics.get(request.getHashCodeSocketMiddle()).totalAdminsOnline++;
                                } else {
                                    serverInformation.middleNodeStatistics.get(request.getHashCodeSocketMiddle()).totalModeratorsOnline++;
                                }
                                requestAnswer.setContent(new Request.LinesEmail(null, loginInfo.getEmail(), user.getRole()));
                                requestAnswer.setMessage("Login successful!");
                            }

                            log = formatter.format(date) + " - Operation : User " + loginInfo.getEmail() + " had successfully logged in as " + user.getRole().toString();
                            serverInformation.clientsOnline++;
                            user.setOnline(true);
                        } else {
                            requestAnswer.setMessage("The password doesn't match!");
                        }
                    }
                    break;

                case REGISTRATION:
                    Request.RegistrationInformation registrationInformation = (Request.RegistrationInformation) request.getContent();
                    //check if the email is already registered
                    if (serverInformation.listOfUsers.get(registrationInformation.getEmail()) != null) {
                        answer = "Email already registered";
                    } else {
                        user = new User(registrationInformation);
                        exporter.appendUsersFile("docs/users.json", user);
                        serverInformation.listOfUsers.put(registrationInformation.getEmail(), user);
                        answer = "Registered";
                        log = formatter.format(date) + " - Operation : Passenger " + registrationInformation.getEmail() + " had successfully registered";
                    }
                    requestAnswer.setMessage(answer);
                    break;

                case ASSOCIATE_LINE:

                    Request.LinesEmail linesInformationToBeAssociated = (Request.LinesEmail) request.getContent();
                    User userTemp = serverInformation.listOfUsers.get(linesInformationToBeAssociated.getEmail());
                    List linesUpdated = new ArrayList();
                    //check if the email is already registered
                    for (Line line : linesInformationToBeAssociated.getLines()) {
                        //check if the line still exists and wasn't already associated
                        if (this.serverInformation.listOfLines.containsKey(line.getName()) && !userTemp.getLinesAssociated().contains(line.getName())) {
                            linesUpdated.add(line);
                        }
                    }
                    //if there was really an update
                    if (linesUpdated.size() > 0) {
                        //check if the number of lines sent are equals then the real update
                        if (linesUpdated.size() == linesInformationToBeAssociated.getLines().size()) {
                            for (Line line : linesInformationToBeAssociated.getLines()) {
                                userTemp.getLinesAssociated().add(line.getName());
                            }
                            serverInformation.listOfUsers.put(linesInformationToBeAssociated.getEmail(), userTemp);
                            exporter.updateUsersFiles("docs/users.json", serverInformation.listOfUsers);
                            requestAnswer.setMessage("Information updated with success!");
                            linesInformationToBeAssociated.setLines(linesUpdated);
                            log = formatter.format(date) + " - Operation : Passenger " + linesInformationToBeAssociated.getEmail() + " had associated lines";
                        } else {
                            linesInformationToBeAssociated.setLines(null);
                            requestAnswer.setMessage("Line(s) sent doesn't exist or are already associated with your account!");
                        }
                    } else {
                        linesInformationToBeAssociated.setLines(null);
                        requestAnswer.setMessage("The given lines are already associated with your account or doesn't exist!");
                    }
                    requestAnswer.setContent(linesInformationToBeAssociated);

                    break;

                case DISSOCIATE_LINE:

                    Request.LinesEmail linesInformation = (Request.LinesEmail) request.getContent();
                    User passenger = serverInformation.listOfUsers.get(linesInformation.getEmail());
                    List linesDissociated = new ArrayList();
                    //check if the email is already registered
                    for (Line line : linesInformation.getLines()) {
                        //check if the line still exists and wasn't already associated
                        if (this.serverInformation.listOfLines.containsKey(line.getName()) && passenger.getLinesAssociated().contains(line.getName())) {
                            linesDissociated.add(line);
                        }
                    }
                    //if there was really an update
                    if (linesDissociated.size() > 0) {
                        //check if passenger is gonna be with at least 1 line associated
                        if (passenger.getLinesAssociated().size() - linesDissociated.size() > 0) {
                            for (Line line : linesInformation.getLines()) {
                                passenger.getLinesAssociated().remove(line.getName());
                            }
                            serverInformation.listOfUsers.put(linesInformation.getEmail(), passenger);
                            exporter.updateUsersFiles("docs/users.json", serverInformation.listOfUsers);
                            requestAnswer.setMessage("Information updated with success!");
                            linesInformation.setLines(linesDissociated);
                            log = formatter.format(date) + " - Operation : Passenger " + linesInformation.getEmail() + " had dissociate lines";
                        } else {
                            linesInformation.setLines(null);
                            requestAnswer.setMessage("You can't delete all your associated lines!");
                        }
                    } else {
                        linesInformation.setLines(null);
                        requestAnswer.setMessage("The given line(s) aren't associated with your account or doesn't exist!");
                    }
                    requestAnswer.setContent(linesInformation);
                    break;

                case ADD_LINE:
                    Request.SingleLineInformation addLinesInfo = (Request.SingleLineInformation) request.getContent();
                    Line lineToAdd = addLinesInfo.getLine();
                    //checks if the line exists
                    if (serverInformation.listOfLines.get(lineToAdd.getName()) != null) {
                        requestAnswer.setMessage("The line already exists");
                        requestAnswer.setContent(null);
                    } else {
                        serverInformation.listOfLines.put(lineToAdd.getName(), lineToAdd);
                        serverInformation.updateRailwayMonitoring = true;
                        exporter.updateLineFile("docs/lines.json", serverInformation.listOfLines);
                        requestAnswer.setMessage("New line added to the system! " + lineToAdd.getName() + " Check the available schedules");
                        log = formatter.format(date) + " - Operation : A new line was added to the network: " + lineToAdd.getName();
                        requestAnswer.setContent(lineToAdd);
                    }
                    break;

                case REMOVE_LINE:
                    Request.SingleLineInformation removeLineInfo = (Request.SingleLineInformation) request.getContent();
                    Line lineToRemove = removeLineInfo.getLine();
                    //checks if the line exists
                    if (serverInformation.listOfLines.get(lineToRemove.getName()) == null) {
                        requestAnswer.setMessage("The line doesn't exists");
                        requestAnswer.setContent(null);
                    } else {
                        serverInformation.listOfLines.remove(lineToRemove.getName());
                        serverInformation.updateRailwayMonitoring = true;
                        exporter.updateLineFile("docs/lines.json", serverInformation.listOfLines);
                        requestAnswer.setMessage("Line removed from the system! " + lineToRemove.getName());
                        log = formatter.format(date) + " - Operation : A line was removed from the network: " + lineToRemove.getName();
                        requestAnswer.setContent(lineToRemove);
                    }
                    break;

                case ADD_SCHEDULE:
                    Request.SchedulesInformation schedulesInformation = (Request.SchedulesInformation) request.getContent();
                    String stringLineToAdd = schedulesInformation.getLine();
                    //checks if the line exists
                    Line lineToUpdate = serverInformation.listOfLines.get(stringLineToAdd);
                    if (lineToUpdate == null) {
                        requestAnswer.setMessage("The line doesn't exists");
                        requestAnswer.setContent(null);
                    } else {
                        if (!schedulesInformation.getSchedules().isEmpty()) {
                            String schedules = "";
                            for (Schedule schedule : schedulesInformation.getSchedules()) {
                                lineToUpdate.addSchedule(schedule);
                                schedules += schedule + "";
                            }
                            serverInformation.listOfLines.put(lineToUpdate.getName(), lineToUpdate);
                            serverInformation.updateRailwayMonitoring = true;
                            exporter.updateLineFile("docs/lines.json", serverInformation.listOfLines);
                            requestAnswer.setMessage("Schedules updated in line " + lineToUpdate.getName() + "! The next schedule(s) were added: " + schedules);
                            log = formatter.format(date) + " - Operation : The schedule(s) were added: " + schedules + " to the line " + lineToUpdate.getName();
                            requestAnswer.setContent(lineToUpdate);
                        }
                    }
                    break;

                case REMOVE_SCHEDULE:
                    Request.SchedulesInformation schedulesToRemove = (Request.SchedulesInformation) request.getContent();
                    String stringLineToRemoveSchedule = schedulesToRemove.getLine();

                    //checks if the line exists
                    Line lineToRemoveSchedule = serverInformation.listOfLines.get(stringLineToRemoveSchedule);
                    if (lineToRemoveSchedule == null) {
                        requestAnswer.setMessage("The line doesn't exists");
                        requestAnswer.setContent(null);
                    } else {
                        String listOfSchedules = "";
                        for (Schedule schedule : schedulesToRemove.getSchedules()) {
                            lineToRemoveSchedule.removeSchedule(schedule);
                            listOfSchedules += schedule.toString() + " ";
                        }
                        serverInformation.listOfLines.put(lineToRemoveSchedule.getName(), lineToRemoveSchedule);
                        serverInformation.updateRailwayMonitoring = true;
                        exporter.updateLineFile("docs/lines.json", serverInformation.listOfLines);
                        requestAnswer.setMessage("Schedules updated in line " + lineToRemoveSchedule.getName() + "! The next schedule(s) were removed: " + listOfSchedules);
                        log = formatter.format(date) + " - Operation : The schedule(s) were removed: " + listOfSchedules + " to the line " + lineToRemoveSchedule.getName();
                        requestAnswer.setContent(lineToRemoveSchedule);
                    }
                    break;

                case SCHEDULE_ALTERATION:

                    HashMap<Line, List<String>> linesToBeWarned = (HashMap<Line, List<String>>) request.getContent();
                    HashMap<Line, String> alterationLines = new HashMap<>();

                    //check lines and schedules sent and only send de alteration to the ones that are correct
                    for (Line line : linesToBeWarned.keySet()) {
                        if (this.serverInformation.listOfLines.containsKey(line.getName()) && line.getSchedulesListString().contains(linesToBeWarned.get(line).get(0))) {
                            alterationLines.put(line, "Attention, there are a temporary alteration in the lines you are subscribing! The line " + line.getName() + " had a alteration on the schedule from " + linesToBeWarned.get(line).get(0) + " to " + linesToBeWarned.get(line).get(1));
                        }
                        log = formatter.format(date) + " - Operation : There were a temporary alteration in the line " + line.getName() + " the schedule changed from " + linesToBeWarned.get(line).get(0) + " to " + linesToBeWarned.get(line).get(1);
                    }

                    requestAnswer.setContent(alterationLines);
                    break;

                case SUSPENDED_TRAFFIC:
                    requestAnswer.setMessage("Attention, all services are suspended!");
                    log = formatter.format(date) + " - Operation : All services were suspended!";
                    break;

                case UNSUSPEND_TRAFFIC:
                    requestAnswer.setMessage("Attention, all services are back!");
                    log = formatter.format(date) + " - Operation : All services were unsuspended!";
                    break;

                case REGISTER_ADMIN:
                    Request.RegistrationInformationBackOffice registrationInformationAdmin = (Request.RegistrationInformationBackOffice) request.getContent();
                    //check if the email is already registered
                    if (serverInformation.listOfUsers.get(registrationInformationAdmin.getEmail()) != null) {
                        answer = "Email already registered";
                    } else {
                        if (registrationInformationAdmin.getSecret().equals(serverInformation.secretAdmin)) {
                            user = new User(registrationInformationAdmin, RoleEnum.ADMIN);
                            exporter.appendUsersFile("docs/users.json", user);
                            serverInformation.listOfUsers.put(registrationInformationAdmin.getEmail(), user);
                            log = formatter.format(date) + " - Operation : Admin " + registrationInformationAdmin.getEmail() + " had successfully registered";
                            answer = "Registered successfully";
                        } else {
                            answer = "You don't have permission to register as admin!";
                        }
                    }
                    requestAnswer.setMessage(answer);
                    break;

                case REGISTER_LOCAL_MANAGER:
                    Request.RegistrationInformationBackOffice registrationInformationLocalManager = (Request.RegistrationInformationBackOffice) request.getContent();
                    //check if the email is already registered
                    if (serverInformation.listOfUsers.get(registrationInformationLocalManager.getEmail()) != null) {
                        answer = "Email already registered";
                    } else {
                        if (registrationInformationLocalManager.getSecret().equals(serverInformation.secretLocalManager)) {
                            user = new User(registrationInformationLocalManager, RoleEnum.LOCALMANAGER);
                            exporter.appendUsersFile("docs/users.json", user);
                            serverInformation.listOfUsers.put(registrationInformationLocalManager.getEmail(), user);
                            log = formatter.format(date) + " - Operation : Local Manager " + registrationInformationLocalManager.getEmail() + " had successfully registered";
                            answer = "Registered successfully";
                        } else {
                            answer = "You don't have permission to register as local manager!";
                        }
                    }
                    requestAnswer.setMessage(answer);
                    break;

                case REPORT_FEEDBACK:
                    Request.WarningInformation warningInformation = (Request.WarningInformation) request.getContent();

                    String message = "A passenger reported an alteration feedback on the line: " + warningInformation.getLine();
                    writeLogFeedback(message, "Passenger said: " + warningInformation.getComment());

                    log = formatter.format(date) + " - Operation : Passenger reported a feedback";

                    requestAnswer.setMessage(message);
                    requestAnswer.setContent("Passenger said: " + warningInformation.getComment());
                    break;

                default:
                    requestAnswer.setMessage("Error trying go process your request");
                    break;
            }
            //registers the log to be written in file
            if (log != null) {
                this.serverInformation.addOperationStringLog(log);
            }
            this.sendMessage(requestAnswer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sendMessage(Request requestAnswer) throws IOException {
        serverInformation.addRequestCount(requestAnswer.getType());
        switch (requestAnswer.getType()) {
            //operations that target a one specific middle node
            case LOGIN, REGISTRATION, REGISTER_ADMIN, REGISTER_LOCAL_MANAGER -> sendToOneMiddleNode(requestAnswer);


            // operations that target all middle nodes
            case ADD_LINE, REMOVE_LINE, ADD_SCHEDULE, REMOVE_SCHEDULE, SUSPENDED_TRAFFIC, SCHEDULE_ALTERATION, REPORT_FEEDBACK, UNSUSPEND_TRAFFIC, ASSOCIATE_LINE, DISSOCIATE_LINE -> sendToAllMiddleNodes(requestAnswer);
        }
    }

    /**
     * Uni cast response
     */
    private void sendToOneMiddleNode(Request request) throws IOException {
        List<Socket> listOfMiddleSockets = serverInformation.middleNodesSockets;

        for (Socket socket : listOfMiddleSockets) {
            if (socket.hashCode() == request.getHashCodeSocketMiddle()) {
                ObjectOutputStream writer = new ObjectOutputStream(socket.getOutputStream());
                writer.writeObject(request);
                return;
            }
        }
    }

    /**
     * Multi cast response and broadcast response
     */
    private void sendToAllMiddleNodes(Request request) throws IOException {
        for (Socket socket : serverInformation.middleNodesSockets) {
            if (socket != null) {
                ObjectOutputStream writer = new ObjectOutputStream(socket.getOutputStream());
                writer.writeObject(request);
            }
        }
    }

    /**
     * Write to log file the feedback by client
     */
    private void writeLogFeedback(String infoLine, String feedbackUser) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        String log = formatter.format(date) + " | " + infoLine + " | " + feedbackUser;

        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("logs/feedbacksPassenger.txt", true)))) {
            out.println(log);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
