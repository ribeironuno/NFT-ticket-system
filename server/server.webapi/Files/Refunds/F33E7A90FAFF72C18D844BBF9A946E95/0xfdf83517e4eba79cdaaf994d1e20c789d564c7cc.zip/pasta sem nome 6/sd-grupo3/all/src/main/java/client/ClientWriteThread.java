package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 * Thread responsible to send the client's request to middle node
 */
public class ClientWriteThread extends Thread {
    private PrintWriter out;
    private BufferedReader in;

    public ClientWriteThread(PrintWriter out, BufferedReader in) {
        this.out = out;
        this.in = in;
    }

    @Override
    public void run() {
        try {
            String userInput;
            while ((userInput = in.readLine()) != null) {
                out.println(userInput);
            }
            System.out.println("write disconnected");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
