package utils;

import centralnode.model.User;
import common.implementation.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.List;

public class Exporter implements IExporter {

    @Override
    public void appendUsersFile(String directoryFile, User user) throws IOException, ParseException {
        JSONParser parser = new JSONParser();
        Reader reader = new FileReader(directoryFile);
        JSONArray users = (JSONArray) parser.parse(reader);

        JSONObject newUser = new JSONObject();
        newUser.put("email", user.getEmail());
        newUser.put("password", user.getPassword());
        newUser.put("name", user.getName());
        newUser.put("role", user.getRole().toString());

        if (user.getRole() == RoleEnum.PASSENGER) {
            newUser.put("lines", user.getLinesAssociated());
        }

        users.add(newUser);

        try (FileWriter file = new FileWriter(directoryFile)) {
            file.write(users.toJSONString());
        } catch (IOException exception) {
            throw new IOException("Users file:  file not found or permission was denied accessing the file");
        }
    }

    public void updateLineFile(String directoryFile, HashMap<String, Line> lines) throws IOException, ParseException {
        JSONArray linesToBeUpdated = new JSONArray();

        for (Line line : lines.values()) {
            JSONObject newLine = new JSONObject();

            newLine.put("name", line.getName());
            JSONArray schedules = new JSONArray();

            for (Schedule schedule : line.getSchedules()) {
                schedules.add(schedule.toString().replace(":", "h"));
            }

            newLine.put("schedules", schedules);

            linesToBeUpdated.add(newLine);
        }

        try (FileWriter file = new FileWriter(directoryFile)) {
            file.write(linesToBeUpdated.toJSONString());
        } catch (IOException exception) {
            throw new IOException("Line file:  file not found or permission was denied accessing the file");
        }
    }

    public void updateUsersFiles(String directoryFile, HashMap<String, User> users) throws IOException, ParseException {
        JSONArray usersToBeUpdated = new JSONArray();

        for (User user : users.values()) {
            JSONObject newUser = new JSONObject();
            newUser.put("name", user.getName());
            newUser.put("role", user.getRole().toString());
            newUser.put("password", user.getPassword());
            newUser.put("email", user.getEmail());

            if (user.getRole() == RoleEnum.PASSENGER) {
                System.out.println(user.getName() + "  NAME");
                JSONArray linesAssociated = new JSONArray();
                List<String> lines = user.getLinesAssociated();
                for (String line : lines) {
                    linesAssociated.add(line);
                }

                newUser.put("lines", linesAssociated);
            }


            usersToBeUpdated.add(newUser);
        }
        try (FileWriter file = new FileWriter(directoryFile)) {
            file.write(usersToBeUpdated.toJSONString());
        } catch (IOException exception) {
            throw new IOException("Line file:  file not found or permission was denied accessing the file");
        }
    }
}
