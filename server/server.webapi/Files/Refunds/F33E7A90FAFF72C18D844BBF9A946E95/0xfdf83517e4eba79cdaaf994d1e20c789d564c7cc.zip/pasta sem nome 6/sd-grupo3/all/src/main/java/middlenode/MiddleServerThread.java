package middlenode;

import model.*;

import java.io.*;
import java.net.DatagramSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Will be listening the central server and will manage the communication with clients.
 */
public class MiddleServerThread extends Thread {
    private Socket socketCentral;
    private MiddleNodeInfo middleNodeInfo;
    private UpdateMessage serverInformation;

    public MiddleServerThread(Socket socketCentral, UpdateMessage serverInformation, MiddleNodeInfo middleNodeInfo) {
        this.socketCentral = socketCentral;
        this.serverInformation = serverInformation;
        this.middleNodeInfo = middleNodeInfo;
    }

    @Override
    public void run() {
        boolean listening = true;
        try {
            OutputStream outFromClient;
            PrintWriter writeToClient;

            while (listening) {
                ObjectInputStream inFromServer = new ObjectInputStream(this.socketCentral.getInputStream());
                Object msgReceived = inFromServer.readObject();
                System.out.println("Server responded");

                try {
                    Request request = (Request) msgReceived;

                    switch (request.getType()) {
                        case LOGIN:
                        case REGISTRATION:
                        case REGISTER_ADMIN:
                        case REGISTER_LOCAL_MANAGER:
                            Socket clientSocket = middleNodeInfo.localSocketsConnections.get(request.getHashCodeSocketClient());
                            outFromClient = clientSocket.getOutputStream();
                            writeToClient = new PrintWriter(outFromClient, true);

                            //if request is login and successful then associate the passenger to his lines
                            if (request.getType() == RequestsEnum.LOGIN && request.getMessage().equals("Login successful!")) {
                                Request.LinesEmail infoLogin = (Request.LinesEmail) request.getContent();
                                //if user is passenger
                                System.out.println(infoLogin.getRole());
                                if (infoLogin.getRole() == RoleEnum.PASSENGER) {
                                    associateLines(infoLogin.getLines(), clientSocket);
                                } else {
                                    updateBackOfficeSockets(clientSocket, infoLogin.getRole());
                                    request.setMessage("Login successful as " + infoLogin.getRole().toString());
                                }
                                updateOnlineClients(request.getHashCodeSocketClient(), infoLogin.getEmail());
                            }
                            writeToClient.println(request.getMessage());
                            break;

                        case ASSOCIATE_LINE:
                            Socket userSocket = middleNodeInfo.localSocketsConnections.get(request.getHashCodeSocketClient());
                            outFromClient = userSocket.getOutputStream();
                            writeToClient = new PrintWriter(outFromClient, true);

                            Request.LinesEmail updatedInfo = (Request.LinesEmail) request.getContent();
                            if (updatedInfo.getLines() != null) {
                                associateLines(updatedInfo.getLines(), userSocket);
                            }

                            writeToClient.println(request.getMessage());
                            break;

                        case DISSOCIATE_LINE:
                            Socket user = middleNodeInfo.localSocketsConnections.get(request.getHashCodeSocketClient());
                            outFromClient = user.getOutputStream();
                            writeToClient = new PrintWriter(outFromClient, true);

                            Request.LinesEmail update = (Request.LinesEmail) request.getContent();
                            if (update.getLines() != null) {
                                for (Line line : update.getLines()) {
                                    ArrayList<Socket> sockets = middleNodeInfo.clientsPerLine.get(line);
                                    sockets.remove(user);
                                    middleNodeInfo.clientsPerLine.put(line, sockets);
                                }
                            }

                            writeToClient.println(request.getMessage());
                            break;

                        case ADD_LINE:
                        case REMOVE_LINE:
                        case ADD_SCHEDULE:
                        case REMOVE_SCHEDULE:
                            if (request.getContent() == null) {
                                clientSocket = middleNodeInfo.localSocketsConnections.get(request.getHashCodeSocketClient());
                                outFromClient = clientSocket.getOutputStream();
                                writeToClient = new PrintWriter(outFromClient, true);
                                writeToClient.println(request.getMessage());
                            } else {
                                //Broadcast
                                middleNodeInfo.broadcastMessages.add(request.getMessage());
                            }
                            break;

                        case SCHEDULE_ALTERATION:
                            HashMap<Line, String> linesToBeWarned = (HashMap<Line, String>) request.getContent();
                            for (Line line : linesToBeWarned.keySet()) {
                                ArrayList<Socket> sockets = middleNodeInfo.clientsPerLine.get(line);
                                for (Socket socketClient : sockets) {
                                    outFromClient = socketClient.getOutputStream();
                                    writeToClient = new PrintWriter(outFromClient, true);
                                    writeToClient.println(linesToBeWarned.get(line));
                                }
                            }
                            break;

                        case SUSPENDED_TRAFFIC:
                        case UNSUSPEND_TRAFFIC:
                            for (int hash : middleNodeInfo.onlineClients.keySet()) {
                                if (middleNodeInfo.localSocketsConnections.containsKey(hash)) {
                                    outFromClient = middleNodeInfo.localSocketsConnections.get(hash).getOutputStream();
                                    writeToClient = new PrintWriter(outFromClient, true);
                                    writeToClient.println(request.getMessage());
                                }
                            }
                            middleNodeInfo.isSuspended = !middleNodeInfo.isSuspended;
                            break;

                        case REPORT_FEEDBACK:
                            Socket[] adminSockets = middleNodeInfo.codeSocketsAdmin.values().toArray(new Socket[0]);
                            Socket[] localManagerSockets = middleNodeInfo.codeSocketsLocalManager.values().toArray(new Socket[0]);
                            for (Socket socketClient : adminSockets) {
                                outFromClient = socketClient.getOutputStream();
                                writeToClient = new PrintWriter(outFromClient, true);
                                writeToClient.println(request.getMessage());
                                writeToClient.println(request.getContent());
                            }
                            for (Socket socketClient : localManagerSockets) {
                                outFromClient = socketClient.getOutputStream();
                                writeToClient = new PrintWriter(outFromClient, true);
                                writeToClient.println(request.getMessage());
                                writeToClient.println(request.getContent());
                            }
                            break;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private synchronized void updateBackOfficeSockets(Socket socket, RoleEnum role) {
        if (role == RoleEnum.ADMIN) {
            middleNodeInfo.codeSocketsAdmin.put(socket.hashCode(), socket);
        } else {
            middleNodeInfo.codeSocketsLocalManager.put(socket.hashCode(), socket);
        }
    }

    private synchronized void updateOnlineClients(int hashCodeSocket, String email) {
        middleNodeInfo.onlineClients.put(hashCodeSocket, email);
    }

    private void associateLines(List<Line> linesToAssociate, Socket client) {
        for (Line line : linesToAssociate) {
            System.out.println(line.getName() + "here");
            if (!middleNodeInfo.clientsPerLine.containsKey(line)) {
                System.out.println("true");
                middleNodeInfo.clientsPerLine.put(line, new ArrayList<>());
            }
            middleNodeInfo.clientsPerLine.get(line).add(client);
        }
    }
}
