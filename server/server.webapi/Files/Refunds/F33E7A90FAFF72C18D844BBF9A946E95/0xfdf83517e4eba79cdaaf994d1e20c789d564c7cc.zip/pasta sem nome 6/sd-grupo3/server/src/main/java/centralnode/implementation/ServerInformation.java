package centralnode.implementation;

import centralnode.model.User;
import common.implementation.*;
import common.interfaces.*;

import java.net.Socket;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Class that contains all information about the instance of server.
 */
public class ServerInformation {
    //passengers registered in the server (online + offline)
    protected HashMap<String, User> listOfUsers = new HashMap<>();
    //list of registered lines
    protected HashMap<String, Line> listOfLines = new HashMap<>();
    //variable that tracks the number of total clients
    protected int clientsOnline = 0;
    //total requests of server
    protected int totalRequests = 0;
    //type of requests counter (name of request, counter)
    protected HashMap<RequestsEnum, Integer> requestsDetailsCounter = new HashMap<>();
    //register the date time that server go up
    protected LocalDateTime upDateTime;
    //flag to update railways in monitoring thread
    protected boolean updateRailwayMonitoring = false;

    //all sockets with the middle nodes
    protected List<Socket> middleNodesSockets = new ArrayList<>();
    //hash map that associates the socket hash with the statistics of a middle node
    protected HashMap<Integer, MiddleNodeStatistics> middleNodeStatistics = new HashMap<>();
    //list of work requests to server
    protected ArrayRequestListSync listOfRequests = new ArrayRequestListSync();
    //list of operations to be logged
    private Queue<String> logOperations = new PriorityQueue<>();

    public class RequestComparator implements Comparator<Request> {
        @Override
        public int compare(Request o1, Request o2) {
            return o1.compareTo(o2);
        }
    }

    //basic information
    protected int port, gatewayPort;
    protected String host;
    //Secret used to check if admin can be registered
    protected String secretAdmin;
    //Secret used to check if local manager can be register
    protected String secretLocalManager;

    public ServerInformation(int port, String host, int gatewayPort, String secretAdmin, String secretLocalManager) {
        this.port = port;
        this.host = host;
        this.gatewayPort = gatewayPort;
        this.secretAdmin = secretAdmin;
        this.secretLocalManager = secretLocalManager;
        this.upDateTime = LocalDateTime.now();
        this.requestsDetailsCounter.put(RequestsEnum.LOGIN, 0);
        this.requestsDetailsCounter.put(RequestsEnum.REGISTRATION, 0);
        this.requestsDetailsCounter.put(RequestsEnum.SUSPENDED_TRAFFIC, 0);
        this.requestsDetailsCounter.put(RequestsEnum.SCHEDULE_ALTERATION, 0);
    }

    protected boolean addUser(User user) {
        listOfUsers.put(user.getEmail(), user);
        return true;
    }

    public int getPort() {
        return this.port;
    }

    public String getHost() {
        return this.host;
    }

    public int totalUsers() {
        return this.listOfUsers.size();
    }

    public void addRequest(Request request) {
        this.listOfRequests.add(request);
    }

    public void addLogOperation(String logOperation) {
        this.logOperations.add(logOperation);
    }

    public int totalConnections() {
        int count = 0;
        MiddleNodeStatistics[] nodes = middleNodeStatistics.values().toArray(new MiddleNodeStatistics[0]);
        for (int i = 0; i < nodes.length; i++) {
            count += nodes[i].totalConnections;
        }
        return count;
    }

    public String getUpTime() {
        Duration duration = Duration.between(this.upDateTime, LocalDateTime.now());
        long days = duration.toDays();
        long hours = duration.toHours() % 24;
        long minutes = duration.toMinutes() % 60;
        long seconds = duration.toSeconds() % 60;

        // Format the result as a string
        return String.format("%d:%02d:%02d:%02d", days, hours, minutes, seconds);
    }

    public void addRequestCount(RequestsEnum type) {
        if (this.requestsDetailsCounter.get(type) != null) {
            this.requestsDetailsCounter.put(type, this.requestsDetailsCounter.get(type) + 1);
        } else {
            this.requestsDetailsCounter.put(type, 1);
        }
    }

    /*
    Adds a new string to be written in text file by the thread responsible by that
     */
    public synchronized void addOperationStringLog(String string) {
        this.logOperations.add(string);
    }

    /**
     * Gets the first operation to write on the log
     *
     * @return
     */
    public synchronized String getOperationStringLog() {
        return logOperations.poll();
    }
}
