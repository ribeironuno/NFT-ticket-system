package utils;

import centralnode.implementation.ServerInformation;
import centralnode.model.User;
import common.implementation.*;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.util.HashMap;

public interface IServerImporter {

    /**
     * Given a directory imports the settings about the server.
     */
    ServerInformation importServiceSettings(String directoryFile) throws IOException, ParseException;

    /**
     * Given a directory import the passenger information.
     */
    HashMap<String, User> importUsersInformation(String directoryFile) throws IOException, ParseException;


    /**
     * Given a directory import the lines information of the network
     */
    HashMap<String, Line> importLinesInformation(String directoryFile) throws IOException, ParseException;
}
