package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Thread responsible to be listening to the broadcast UDP server
 */
public class ClientReadUdpThread extends Thread {
    private DatagramSocket udpSocket;

    public ClientReadUdpThread(DatagramSocket udpSocket) {
        this.udpSocket = udpSocket;
    }

    @Override
    public void run() {
        try {
            while (true) {
                // Create a buffer to receive incoming data
                byte[] buf = new byte[256];
                DatagramPacket packet = new DatagramPacket(buf, buf.length);

                // Listen for incoming broadcast messages
                udpSocket.receive(packet);

                // Print the received message
                String message = new String(packet.getData(), 0, packet.getLength());
                System.out.println(message);
            }
            //check if the server disconnected
        } catch (SocketException se) {
            udpSocket.close();
        } catch (IOException ex) {
            Logger.getLogger(this.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


