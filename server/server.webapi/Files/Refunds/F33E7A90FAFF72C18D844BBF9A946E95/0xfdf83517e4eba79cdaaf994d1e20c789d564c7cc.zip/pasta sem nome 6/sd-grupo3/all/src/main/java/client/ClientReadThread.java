package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Thread responsible to listening to middle node
 */
public class ClientReadThread extends Thread {

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private List<Boolean> byeSignal;

    public ClientReadThread(Socket socket, BufferedReader in, PrintWriter out, List<Boolean> byeSignal) {
        this.socket = socket;
        this.in = in;
        this.out = out;
        this.byeSignal = byeSignal;
    }

    @Override
    public void run() {
        try {
            String msgFromServer;
            //waits for server message (middle node message)

            while (byeSignal.isEmpty() && !socket.isClosed() && (msgFromServer = in.readLine()) != null) {
                //user wants to disconnect
                if (msgFromServer.equals("Thank you for choosing our service!")) {
                    out.close();
                    in.close();
                    //sets the signal that user disconnected
                    byeSignal.add(true);
                    socket.close();
                }
                System.out.println(msgFromServer);
            }
            System.out.println("read disconnected");

            //check if the server disconnected
        } catch (SocketException se) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (IOException ex) {
            Logger.getLogger(this.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

