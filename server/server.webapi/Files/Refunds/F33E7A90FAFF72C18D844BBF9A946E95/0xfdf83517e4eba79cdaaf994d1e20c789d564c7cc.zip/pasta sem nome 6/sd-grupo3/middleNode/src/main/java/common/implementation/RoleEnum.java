package common.implementation;

/**
 * PASSENGER -> Ordinary user of the system. Receive updates and can send feedback of the service
 * LOCALMANAGER -> User responsible to send scheduled warning delays, and suspend the network
 * ADMIN -> Master user, has the functionalities of a local manager and also can define the schedules of the lines
 */
public enum RoleEnum {
    PASSENGER, LOCALMANAGER, ADMIN;

    /*
     * Convert enumeration to appropriate string
     */
    public String toString() {
        switch (this) {
            case PASSENGER: return  "Passenger";
            case LOCALMANAGER: return "Local Manager";
            case ADMIN: return  "Admin";
        }
        return null;
    }
}


