package client;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * Class that represents a client
 */
public class Client {

    public static void main(String[] args) {
        execute();
    }

    //method that will start up the client program
    public static void execute() {
        boolean isConnected = false;
        int numberOfTries = 0;
        Socket serverSocket = null;
        DatagramSocket udpServer = null;
        String serverPortString;
        //list that will track when a user wants to leave the system
        List<Boolean> byeSignal = new ArrayList<>();

        //keeps trying until reaches 5 tries
        while (!isConnected && numberOfTries < 5) {
            //sets the force brute data connection
            String host = "localhost";
            int gatewayPort = 2001;

            //connects with server gateway
            Socket gatewayServer;
            try {
                gatewayServer = new Socket(host, gatewayPort);
            } catch (IOException e) {
                System.err.println("Client cannot connect with gateway!");
                numberOfTries++;
                continue;
            }

            BufferedReader inFromGateway;
            try {
                //prepare buffer to read from gateway the ideal port
                inFromGateway = new BufferedReader(new InputStreamReader(gatewayServer.getInputStream()));
            } catch (IOException e) {
                System.err.println("Something went wrong! Trying again!");
                numberOfTries++;
                continue;
            }

            try {
                //read the port
                boolean flagReadLine = true;
                while (flagReadLine && (serverPortString = inFromGateway.readLine()) != null) {
                    //check if the port received is an int
                    if (serverPortString.matches("^\\d+ \\d+$")) {
                        String[] split = serverPortString.split(" ");
                        int tcpServerPort = Integer.parseInt(split[0]);
                        int udpPortInt = Integer.parseInt(split[1]);
                        try {
                            //try to connect with the middle node port given
                            serverSocket = new Socket(host, tcpServerPort);
                            isConnected = true;
                            //tries to connect to UDP, sends the request to be added to the broadcast list
                            udpServer = new DatagramSocket();
                            InetAddress address = InetAddress.getByName("localhost");
                            DatagramPacket request = new DatagramPacket(new byte[1], 1, address, udpPortInt);
                            udpServer.send(request);

                            System.out.println("Connected in port " + tcpServerPort + " (TCP) and subscribed " + udpPortInt + " (UDP)");
                            System.out.println("Write 'help' to see all the available functionalities");
                            break;
                        } catch (IOException e) {
                            System.err.println("Connection with a middle node in port " + serverPortString + " failed!");
                            numberOfTries++;
                            flagReadLine = false;
                        }
                    } else {
                        System.err.println("At the moment there is no ports to connect");
                        System.exit(-1);
                    }
                }
            } catch (IOException e) {
                continue;
            }
        }

        if (numberOfTries >= 5) {
            System.err.println("Number of tries exceeded! Server must be down! Try again later");
            System.exit(-1);
        }

        try {
            //socket read buffer
            BufferedReader inFromLocalNode = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));

            //socket writer
            PrintWriter outToLocalNode = new PrintWriter(serverSocket.getOutputStream(), true);

            //keyboard
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

            //starts write thread (write to middle node associated)
            ClientWriteThread writeClient = new ClientWriteThread(outToLocalNode, userInput);
            writeClient.start();

            //starts read thread (read from the middle node associated)
            ClientReadThread readClient = new ClientReadThread(serverSocket, inFromLocalNode, outToLocalNode, byeSignal);
            readClient.start();

            //starts read thread (read from the middle node associated)
            ClientReadUdpThread clientReadUdpThread = new ClientReadUdpThread(udpServer);
            clientReadUdpThread.start();

            //waits until the server disconnect (secure action only) and tries to reconnect
            while (!serverSocket.isClosed()) {
                Thread.sleep(1000);
            }
            //from now on: prepare to reconnect or to exit

            //closes the udp socket
            if (udpServer != null) {
                udpServer.close();
            }
            //if it's empty was a lost connection, if not was a client attempt to disconnect
            //if was lost connection tries to reconnect if not exits the program
            if (byeSignal.isEmpty()) {
                execute();
            } else {
                System.exit(0);
            }
        } catch (IOException e) {
            System.err.println("Something went wrong! Cancelling connection! Try again later");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}