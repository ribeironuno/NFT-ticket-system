package middlenode.implementation;

import common.implementation.UpdateMessage;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

/**
 * Updates the middle node status with server information
 */
public class MiddleServerUpdateThread extends Thread {
    private Socket socketUpdate;
    private MiddleNodeInfo middleNodeInfo;


    public MiddleServerUpdateThread(Socket socketUpdate, MiddleNodeInfo middleNodeInfo) {
        this.socketUpdate = socketUpdate;
        this.middleNodeInfo = middleNodeInfo;
    }

    @Override
    public void run() {
        try {
            while (true) {
                ObjectInputStream inFromServer = new ObjectInputStream(this.socketUpdate.getInputStream());
                Object msgReceived = inFromServer.readObject();
                try {
                    UpdateMessage updateMessage = (UpdateMessage) msgReceived;
                    updateInformation(updateMessage);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Thread.sleep(500);
            }
        } catch (IOException | ClassNotFoundException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void updateInformation(UpdateMessage newInfo) {
        this.middleNodeInfo.lines = newInfo.lines;
    }
}