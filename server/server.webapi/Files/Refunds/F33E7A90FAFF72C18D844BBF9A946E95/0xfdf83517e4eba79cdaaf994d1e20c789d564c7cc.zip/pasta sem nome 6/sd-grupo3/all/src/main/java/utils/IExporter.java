package utils;

import model.User;
import org.json.simple.parser.ParseException;

import java.io.IOException;

public interface IExporter {

    /**
     * Given a directory update the information on that file by appending the data of a new user.
     */
    void appendUsersFile(String directoryFile, User user) throws IOException, ParseException;
}
