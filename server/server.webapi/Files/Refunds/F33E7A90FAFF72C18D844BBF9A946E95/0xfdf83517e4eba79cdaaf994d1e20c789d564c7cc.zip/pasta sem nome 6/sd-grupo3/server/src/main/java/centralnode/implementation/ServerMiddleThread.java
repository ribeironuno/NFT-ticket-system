package centralnode.implementation;

import common.implementation.*;
import common.interfaces.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

/**
 * Will handle the communication between a server and a middle node (server <- middle node).
 * After receiving a request from a client sends it to the server or handles the request in case of receiving
 * a logout or a new connection request.
 */
public class ServerMiddleThread extends Thread {

    private Socket middleSocket;
    private ServerInformation serverInformation;
    private MiddleNodeStatistics middleNodeStatistics;

    public ServerMiddleThread(Socket middleSocket, ServerInformation serverInformation, MiddleNodeStatistics middleNodeStatistics) {
        this.middleSocket = middleSocket;
        this.serverInformation = serverInformation;
        this.middleNodeStatistics = middleNodeStatistics;
    }

    @Override
    public void run() {
        Object msgReceived;
        Request request;
        try {
            while (!middleSocket.isClosed()) {
                ObjectInputStream inFromServer = new ObjectInputStream(this.middleSocket.getInputStream());
                msgReceived = inFromServer.readObject();

                try {
                    request = (Request) msgReceived;
                    serverInformation.middleNodeStatistics.get(middleSocket.hashCode()).totalRequests++;
                    serverInformation.totalRequests++;
                    serverInformation.addRequestCount(request.getType());
                    switch (request.getType()) {

                        case NEW_CONNECTION:
                            serverInformation.middleNodeStatistics.get(middleSocket.hashCode()).totalConnections++;
                            break;

                        case LOGOUT:
                            RoleEnum role = (RoleEnum) request.getContent();
                            switch (role) {
                                case PASSENGER -> serverInformation.middleNodeStatistics.get(middleSocket.hashCode()).totalClientsOnline--;
                                case ADMIN -> serverInformation.middleNodeStatistics.get(middleSocket.hashCode()).totalAdminsOnline--;
                                case LOCALMANAGER -> serverInformation.middleNodeStatistics.get(middleSocket.hashCode()).totalModeratorsOnline--;
                            }
                            serverInformation.clientsOnline--;
                            break;

                        case EXIT:
                            serverInformation.middleNodeStatistics.get(middleSocket.hashCode()).totalConnections--;
                            break;

                        default:
                            request.setHashCodeSocketMiddle(middleSocket.hashCode());
                            serverInformation.addRequest(request);
                            break;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            //when middle node disconnect
            System.err.println("Middle node " + middleSocket.getLocalAddress() + ":" + middleSocket.getPort() + " stopped");

            //remove the number of clients
            serverInformation.clientsOnline -= (middleNodeStatistics.totalClientsOnline + middleNodeStatistics.totalAdminsOnline
                    + middleNodeStatistics.totalModeratorsOnline);

            //remove from the middle node statistics
            serverInformation.middleNodeStatistics.remove(middleSocket.hashCode());

            //remove from the list of sockets
            serverInformation.middleNodesSockets.remove(middleSocket);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
