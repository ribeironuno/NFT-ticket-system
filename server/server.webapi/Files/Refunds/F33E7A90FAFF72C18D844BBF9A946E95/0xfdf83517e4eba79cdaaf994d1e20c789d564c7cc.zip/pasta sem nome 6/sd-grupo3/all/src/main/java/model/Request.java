package model;

import java.io.Serializable;
import java.util.List;

/**
 * Represents a request to be transfer between server and request
 */
public class Request implements Comparable<Request>, Serializable {

    public enum RequestPriorityEnum {
        LOW, MEDIUM, HIGH
    }

    //the hash code of a client in order to middle node identify the client
    private int hashCodeSocketClient;
    //hash code of middle server to server identify which middle call
    private int hashCodeSocketMiddle;
    private int portMiddle;
    private RequestPriorityEnum priority;
    private String to;
    private RequestsEnum type;

    Object content;
    String message;

    public Request(int hashCodeSocket, int portMiddle, String to, RequestsEnum type, Object content) {
        //sets the priority
        switch (type) {

            case ADD_LINE, REPORT_FEEDBACK -> this.priority = RequestPriorityEnum.MEDIUM;

            case SUSPENDED_TRAFFIC, SCHEDULE_ALTERATION -> this.priority = RequestPriorityEnum.HIGH;

            default -> this.priority = RequestPriorityEnum.LOW;
        }
        this.hashCodeSocketClient = hashCodeSocket;
        this.portMiddle = portMiddle;
        this.to = to;
        this.type = type;
        this.content = content;
    }

    public void setHashCodeSocketClient(int hashCodeSocketClient) {
        this.hashCodeSocketClient = hashCodeSocketClient;
    }

    public void setHashCodeSocketMiddle(int hashCodeSocketMiddle) {
        this.hashCodeSocketMiddle = hashCodeSocketMiddle;
    }

    public void setPortMiddle(int portMiddle) {
        this.portMiddle = portMiddle;
    }

    public void setPriority(RequestPriorityEnum priority) {
        this.priority = priority;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public void setType(RequestsEnum type) {
        this.type = type;
    }

    public void setContent(Object content) {
        this.content = content;
    }

    public int getHashCodeSocketClient() {
        return hashCodeSocketClient;
    }

    public int getHashCodeSocketMiddle() {
        return hashCodeSocketMiddle;
    }

    public int getPortMiddle() {
        return portMiddle;
    }

    public RequestsEnum getType() {
        return type;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return this.message;
    }

    public Object getContent() {
        return this.content;
    }

    public String getTo() {
        return this.to;
    }

    public RequestPriorityEnum getPriority() {
        return this.priority;
    }

    @Override
    public int compareTo(Request o) {
        if (o.priority.ordinal() == this.priority.ordinal()) {
            return 0;
        } else {
            return o.priority.ordinal() - this.priority.ordinal();
        }
    }

    public static class LoginInformation implements Serializable {
        String email;

        String password;

        public LoginInformation(String email, String password) {
            this.email = email;
            this.password = password;
        }

        public String getEmail() {
            return email;
        }

        public String getPassword() {
            return password;
        }
    }

    public static class RegistrationInformation implements Serializable {
        String email;
        String name;
        String password;
        List linesAssociated;

        public String getEmail() {
            return email;
        }

        public String getName() {
            return name;
        }

        public String getPassword() {
            return password;
        }

        public List getLinesAssociated() {
            return linesAssociated;
        }

        public RegistrationInformation(String email, String name, String password, List linesAssociated) {
            this.email = email;
            this.password = password;
            this.name = name;
            this.linesAssociated = linesAssociated;
        }
    }

    public static class RegistrationInformationBackOffice implements Serializable {
        String email;
        String name;
        String password;
        String secret;

        public String getEmail() {
            return email;
        }

        public String getName() {
            return name;
        }

        public String getPassword() {
            return password;
        }

        public String getSecret() {
            return secret;
        }

        public RegistrationInformationBackOffice(String email, String name, String password, String secret) {
            this.email = email;
            this.password = password;
            this.name = name;
            this.secret = secret;
        }
    }

    public static class SingleLineInformation implements Serializable {
        Line lines;

        public Line getLine() {
            return lines;
        }

        public SingleLineInformation(Line lines) {
            this.lines = lines;
        }
    }

    public static class SchedulesInformation implements Serializable {
        private List<Schedule> schedules;
        private String lineName;

        public SchedulesInformation(String lineName, List<Schedule> schedules) {
            this.schedules = schedules;
            this.lineName = lineName;
        }

        public List<Schedule> getSchedules() {
            return schedules;
        }

        public String getLine() {
            return lineName;
        }
    }

    public static class WarningInformation implements Serializable {
        String line;
        String comment;

        public String getLine() {
            return line;
        }

        public String getComment() {
            return comment;
        }

        public WarningInformation(String line, String comment) {
            this.line = line;
            this.comment = comment;
        }
    }

    public static class LinesEmail implements Serializable {
        List<Line> lines;
        String email;

        RoleEnum role;

        public List<Line> getLines() {
            return lines;
        }

        public String getEmail() {
            return email;
        }

        public RoleEnum getRole(){return role;}

        public void setLines(List<Line> lines) {
            this.lines = lines;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setRole(RoleEnum role) {
            this.role = role;
        }

        public LinesEmail(List<Line> lines, String email, RoleEnum role) {
            this.lines = lines;
            this.email = email;
            this.role = role;
        }
    }
}
