package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

//Class that represents on line
public class Line implements Serializable {

    //name of line
    private String name;
    //list of schedules
    private List<Schedule> schedules = new ArrayList<>();

    public Line(String name) {
        this.name = name;
    }

    //gets line name
    public String getName() {
        return name;
    }

    //adds a new schedule to the line
    public boolean addSchedule(Schedule schedule) {
        if (!this.schedules.contains(schedule)) {
            this.schedules.add(schedule);
        }
        return false;
    }

    //adds a a list of schedules
    public void addScheduleList(List<Schedule> schedules) {
        for (Schedule schedule : schedules) {
            addSchedule(schedule);
        }
    }

    // check if the schedules sent are present on the list of schedules associated with that line
    public boolean checkSchedulesExists(List<Schedule> scheduleToBeChecked) {
        boolean exists = true;
        for (Schedule schedule : scheduleToBeChecked) {
            if (!this.schedules.contains(schedule)) {
                exists = false;
            }
        }
        return exists;
    }


    //remove a schedule
    public boolean removeSchedule(Schedule schedule) {
        return this.schedules.remove(schedule);
    }

    //gets the list of schedules
    public List<Schedule> getSchedules() {
        return this.schedules;
    }

    //gets the list of schedules
    public List<String> getSchedulesListString() {
        List<String> tmpScheduleList = new ArrayList<>();
        for (Schedule schedule : this.schedules) {
            tmpScheduleList.add(schedule.toString().replace(":", "h"));
        }
        return tmpScheduleList;
    }

    //returns the string of the schedules
    public String getSchedulesString() {
        StringBuilder stringBuilder = new StringBuilder();

        if (this.schedules.size() == 0) {
            stringBuilder.append("No schedules associated");
        } else {
            int count = 0;
            for (Schedule schedule : this.schedules) {
                count++;
                if (count > 10) {
                    stringBuilder.append("\n");
                    count = 0;
                }
                stringBuilder.append(schedule.toString() + "      ");
            }
        }
        return stringBuilder.toString();
    }

    @Override
    public String toString() {
        return "Line{" +
                "name='" + name + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Line line = (Line) o;
        return Objects.equals(name, line.name);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + name.length();
        return result;
    }
}
