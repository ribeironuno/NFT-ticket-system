package common.interfaces;

import java.io.Serializable;

/**
 * Interface for schedule
 */
public interface ISchedule extends Serializable {

    //gets hours
    public int getHours();

    //get minutes
    public int getMinutes();
}
