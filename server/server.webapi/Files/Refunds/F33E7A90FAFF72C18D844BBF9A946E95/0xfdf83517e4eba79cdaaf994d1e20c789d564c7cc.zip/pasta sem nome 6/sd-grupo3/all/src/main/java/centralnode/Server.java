package centralnode;

import org.json.simple.parser.ParseException;
import utils.ServerImporter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * Class that represents the server.
 */
public class Server {
    public static void main(String[] args) {
        ServerImporter importer = new ServerImporter();

        //read the settings file (contains all information to start up a server)
        ServerInformation serverInformation = null;
        try {
            serverInformation = importer.importServiceSettings("docs/settings.json");
        } catch (IOException e) {
            System.err.println("Error reaching the file settings file! Verify the location");
            System.exit(-1);
        } catch (ParseException e) {
            System.err.println("Error parsing the file! Verify the content of settings file!");
            System.exit(-1);
        }

        //last check in settings file
        if (serverInformation == null || !settingsFileReadIsValid(serverInformation)) {
            System.err.println("Some problem occurred getting the settings file! Verify the rules applied to the file! Server can't go up!");
            System.exit(-1);
        }

        //list of threads for each connection (server <- middle node)
        List<ServerMiddleThread> serverMiddleThreads = new ArrayList<>();
        boolean listening = true;
        try {
            System.out.println("### Server started in port " + serverInformation.port + " ###");

            //server socket
            ServerSocket serverSocket = new ServerSocket(serverInformation.port);
            //socket that will be responsible to update the middle node
            ServerSocket updateSocket = new ServerSocket(serverInformation.port - 1);
            //socket that will be responsible to sycn the clock of the MiddleNodes
            DatagramSocket syncSocket = new DatagramSocket(serverInformation.port - 2);

            //start server monitoring thread
            ServerMonitoringThread serverMonitoringThread = new ServerMonitoringThread(serverInformation);
            serverMonitoringThread.start();

            //read passenger file
            ServerReadUsersFile serverReadUsersFile = new ServerReadUsersFile(serverInformation);
            serverReadUsersFile.start();

            //read lines file
            ServerReadLinesFile serverReadLinesFile = new ServerReadLinesFile(serverInformation);
            serverReadLinesFile.start();

            //start server gateway
            ServerGateway serverGateway = new ServerGateway(serverInformation.gatewayPort, serverInformation);
            serverGateway.start();

            //start work thread
            WorkThread workThread = new WorkThread(serverInformation);
            workThread.start();

            //start work thread
            ClockServerThread clockServerThread = new ClockServerThread(syncSocket);
            clockServerThread.start();

            while (listening) {
                //receive a new middleNode
                Socket localNodeSocket = serverSocket.accept();
                Socket localNodeUpdateSocket = updateSocket.accept();

                //receive the host and the port that middle node will be listening
                BufferedReader inFromMiddle = null;
                String[] splitIn;
                try {
                    //prepare buffer to read from gateway the ideal port
                    inFromMiddle = new BufferedReader(new InputStreamReader(localNodeSocket.getInputStream()));
                    splitIn = inFromMiddle.readLine().split(" ");
                } catch (IOException e) {
                    System.err.println("Cannot read the host + TCP port + UDP port from the recently node connected!");
                    continue;
                }

                //ads the middle node socket to list
                serverInformation.middleNodesSockets.add(localNodeSocket);
                System.out.println("Server: New middle node connected");

                //create a new middle node information
                MiddleNodeStatistics middleNodeStatistics =
                        new MiddleNodeStatistics(localNodeSocket.hashCode(),
                                Integer.parseInt(splitIn[1]),
                                splitIn[0],
                                Integer.parseInt(splitIn[2]));
                
                serverInformation.middleNodeStatistics.put(localNodeSocket.hashCode(), middleNodeStatistics);

                //thread that will handle the communication connection (server <- middle node)
                ServerMiddleThread serverMiddleThread = new ServerMiddleThread(localNodeSocket, serverInformation, middleNodeStatistics);
                serverMiddleThread.start();
                serverMiddleThreads.add(serverMiddleThread);

                //starts the thread responsible to send updates to the middle node
                ServerMiddleUpdateThread updateThread = new ServerMiddleUpdateThread(localNodeUpdateSocket, serverInformation);
                updateThread.start();
            }
            serverSocket.close();
        } catch (IOException e) {
            System.err.println("Could not set server on port: " + serverInformation.port);
            System.exit(-1);
        }
    }

    /**
     * Given an instance of ServerInformation checks if it's valid against domain rules
     */
    public static boolean settingsFileReadIsValid(ServerInformation serverInformation) {
        if (serverInformation.getHost() == null || serverInformation.getHost().isEmpty()) {
            return false;
        }
        if (serverInformation.getPort() < 0) {
            return false;
        }
        if (serverInformation.secretAdmin == null || serverInformation.secretLocalManager == null) {
            return false;
        }
        if (serverInformation.gatewayPort < 0) {
            return false;
        }
        return true;
    }
}
