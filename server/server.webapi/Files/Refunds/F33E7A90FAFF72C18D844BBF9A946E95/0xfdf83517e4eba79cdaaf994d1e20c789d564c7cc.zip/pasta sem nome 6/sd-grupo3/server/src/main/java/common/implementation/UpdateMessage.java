package common.implementation;

import java.io.Serializable;
import java.util.HashMap;

/**
 * Object that will contain the information to update middle node information
 */
public class UpdateMessage implements Serializable {
    public HashMap<String, Line> lines;

    public UpdateMessage(HashMap<String, Line> lines){
        this.lines = lines;
    }
}
