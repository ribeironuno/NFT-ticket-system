package model;

import java.io.Serializable;
import java.util.List;

public class User implements Serializable {

    String email;
    String password;
    String name;
    RoleEnum role;
    List linesAssociated;
    Boolean online;

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    public RoleEnum getRole() {
        return role;
    }

    public List getLinesAssociated() {
        return linesAssociated;
    }

    public void setOnline(Boolean online) {
        this.online = online;
    }

    @Override
    public String toString() {
        return "User{" +
                "email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                ", role=" + role +
                ", linesAssociated=" + linesAssociated +
                ", online=" + online +
                '}';
    }

    public User(String email, String password, String name, List linesAssociated) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.linesAssociated = linesAssociated;
        this.role = RoleEnum.PASSENGER;
        this.online = false;
    }

    public User(String email, String password, String name, RoleEnum role) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.linesAssociated = null;
        this.role = role;
        this.online = false;
    }

    //create a user of type passenger from the registration information
    public User(Request.RegistrationInformation registrationInformation) {
        this.email = registrationInformation.email;
        this.password = registrationInformation.password;
        this.name = registrationInformation.name;
        this.role = RoleEnum.PASSENGER;
        this.linesAssociated = registrationInformation.linesAssociated;
        this.online = false;
    }

    //create a back-office from the registration information
    public User(Request.RegistrationInformationBackOffice RegistrationInformationBackOffice, RoleEnum role) {
        this.email = RegistrationInformationBackOffice.email;
        this.password = RegistrationInformationBackOffice.password;
        this.name = RegistrationInformationBackOffice.name;
        this.role = role;
        this.linesAssociated = null;
        this.online = false;
    }
}
