package middlenode;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

/**
 * Thread that will be responsible to be listening to a client subscription and
 * add the ip + port to the udp receivers lsit
 */
public class MiddleUdpReceiveThread extends Thread {

    private MiddleNodeInfo middleNodeInfo;
    private DatagramSocket udpSocket;

    public MiddleUdpReceiveThread(DatagramSocket udpSocket, MiddleNodeInfo middleNodeInfo) {
        this.middleNodeInfo = middleNodeInfo;
        this.udpSocket = udpSocket;
    }

    @Override
    public void run() {
        while (true) {
            try {
                byte[] receiveMsg = new byte[1];
                DatagramPacket receivePacket = new DatagramPacket(receiveMsg, 1);

                //waits for the client "subscription"
                this.udpSocket.receive(receivePacket);

                //if ip it's already registered
                if (middleNodeInfo.ipAndPortToBroadcast.get(receivePacket.getAddress()) == null) {
                    List<Integer> list = new ArrayList<>();
                    list.add(receivePacket.getPort());
                    middleNodeInfo.ipAndPortToBroadcast.put(receivePacket.getAddress(), list);
                } else {
                    middleNodeInfo.ipAndPortToBroadcast.get(receivePacket.getAddress()).add(receivePacket.getPort());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
