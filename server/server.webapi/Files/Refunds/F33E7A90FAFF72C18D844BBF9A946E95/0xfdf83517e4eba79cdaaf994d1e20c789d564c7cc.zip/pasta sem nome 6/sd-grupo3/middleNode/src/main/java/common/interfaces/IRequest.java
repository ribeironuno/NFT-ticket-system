package common.interfaces;

import common.implementation.*;

import java.io.Serializable;
import java.util.List;

/**
 * Interface that sets the rules to communicate.
 * <p>
 * Defines the classes that will be transferred in the messages.
 */
public interface IRequest extends Comparable<Request>, Serializable {

    /* Methods */

    void setHashCodeSocketClient(int hashCodeSocketClient);

    void setHashCodeSocketMiddle(int hashCodeSocketMiddle);

    void setPortMiddle(int portMiddle);

    void setPriority(Request.RequestPriorityEnum priority);

    void setTo(String to);

    void setType(RequestsEnum type);

    void setContent(Object content);

    int getHashCodeSocketClient();

    int getHashCodeSocketMiddle();

    int getPortMiddle();

    RequestsEnum getType();

    void setMessage(String message);

    String getMessage();

    Object getContent();

    String getTo();

    Request.RequestPriorityEnum getPriority();

    /* Enum */

    //priority of a request
    enum RequestPriorityEnum {
        LOW, MEDIUM, HIGH
    }

    /* Static Classes */

    /**
     * Login object to be transferred
     */
    class LoginInformation implements Serializable {
        private String email;
        private String password;

        public LoginInformation(String email, String password) {
            this.email = email;
            this.password = password;
        }

        public String getEmail() {
            return email;
        }

        public String getPassword() {
            return password;
        }
    }

    /**
     * Registration object to be transferred
     */
    class RegistrationInformation implements Serializable {
        private  String email;
        private  String name;
        private  String password;
        private  List linesAssociated;

        public String getEmail() {
            return email;
        }

        public String getName() {
            return name;
        }

        public String getPassword() {
            return password;
        }

        public List getLinesAssociated() {
            return linesAssociated;
        }

        public RegistrationInformation(String email, String name, String password, List linesAssociated) {
            this.email = email;
            this.password = password;
            this.name = name;
            this.linesAssociated = linesAssociated;
        }
    }

    /**
     * Registration backoffice object to be transferred
     */
    class RegistrationInformationBackOffice implements Serializable {
        private  String email;
        private  String name;
        private   String password;
        private  String secret;

        public String getEmail() {
            return email;
        }

        public String getName() {
            return name;
        }

        public String getPassword() {
            return password;
        }

        public String getSecret() {
            return secret;
        }

        public RegistrationInformationBackOffice(String email, String name, String password, String secret) {
            this.email = email;
            this.password = password;
            this.name = name;
            this.secret = secret;
        }
    }

    /**
     * Single line object to be transferred
     */
    class SingleLineInformation implements Serializable {
        private Line lines;

        public Line getLine() {
            return lines;
        }
        public SingleLineInformation(Line lines) {
            this.lines = lines;
        }
    }

    /**
     * Class to send in a schedules' info request
     */
    class SchedulesInformation implements Serializable {
        private List<Schedule> schedules;
        private String lineName;

        public SchedulesInformation(String lineName, List<Schedule> schedules) {
            this.schedules = schedules;
            this.lineName = lineName;
        }

        public List<Schedule> getSchedules() {
            return schedules;
        }

        public String getLine() {
            return lineName;
        }
    }

    /**
     * Class to send in a warning info
     */
    class WarningInformation implements Serializable {
        private String line;
        private String comment;

        public String getLine() {
            return line;
        }

        public String getComment() {
            return comment;
        }

        public WarningInformation(String line, String comment) {
            this.line = line;
            this.comment = comment;
        }
    }

    /**
     * Class to send in a lines
     */
    class LinesEmail implements Serializable {
        private List<Line> lines;
        private String email;

        private RoleEnum role;

        public List<Line> getLines() {
            return lines;
        }

        public String getEmail() {
            return email;
        }

        public RoleEnum getRole() {
            return role;
        }

        public void setLines(List<Line> lines) {
            this.lines = lines;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setRole(RoleEnum role) {
            this.role = role;
        }

        public LinesEmail(List<Line> lines, String email, RoleEnum role) {
            this.lines = lines;
            this.email = email;
            this.role = role;
        }
    }
}
