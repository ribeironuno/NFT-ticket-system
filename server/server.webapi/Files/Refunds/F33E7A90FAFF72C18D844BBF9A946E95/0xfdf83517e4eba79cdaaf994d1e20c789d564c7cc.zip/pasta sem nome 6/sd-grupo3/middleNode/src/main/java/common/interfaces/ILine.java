package common.interfaces;

import common.implementation.Schedule;

import java.io.Serializable;
import java.util.List;

/**
 * Interface that dictates the rules in line obj
 */
public interface ILine extends Serializable {

    //remove a schedule
    boolean removeSchedule(Schedule schedule);

    //gets the list of schedules
    List<Schedule> getSchedules();

    //gets the list of schedules
    List<String> getSchedulesListString();

    //returns the string of the schedules
    String getSchedulesString();
}
