package middlenode.implementation;

import common.implementation.UpdateMessage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Thread that will be registering the logs about middle nodes.
 */
public class MiddleNodeMonitoring extends Thread {
    private MiddleNodeInfo middleNodeInfo;
    private UpdateMessage serverInformation;

    public MiddleNodeMonitoring(MiddleNodeInfo middleNodeInfo, UpdateMessage serverInformation) {
        this.middleNodeInfo = middleNodeInfo;
        this.serverInformation = serverInformation;
    }

    @Override
    public void run() {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date;
        String logString;
        try {
            while (true) {
                date = new Date();
                logString = formatter.format(date) + " - Middle node status (" + middleNodeInfo.tcpPort + ") : " +
                        "Clients connected " + middleNodeInfo.localSocketsConnections.size();
                System.out.println(logString);
                try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("logs/logMiddleNode" + middleNodeInfo.tcpPort + ".txt", true)))) {
                    out.println(logString);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Thread.sleep(30000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
