package centralnode;

import model.Line;
import model.RequestsEnum;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Thread that will register the logs of server.
 */
public class ServerMonitoringThread extends Thread {
    ServerInformation serverInformation;

    private String directory = "docs/graphs";

    private boolean graphVizSupported = true;
    private int graphViErrorCounter = 0;

    private boolean compactView = true;

    //graph
    private final JFrame frameGraph = new JFrame("Visualization of server status");
    private JLabel lblIcon = new JLabel();

    //text
    private final JFrame frameText = new JFrame("Visualization of server status");
    private JLabel lblUpTime;
    private JLabel lblTitle;
    private JLabel lblTotalClients;
    private JLabel lblTotalClientsOnline;
    private JLabel lblTotalNodes;
    private JLabel lblTotalConnections;
    private JLabel lblTotalRequests;
    private JLabel lblTotalRailways;
    private JLabel lblTotalLogin;
    private JLabel lblTotalRegistration;
    private JLabel lblTotalSuspension;
    private JLabel lblTotalAlteration;
    private JButton btnOpenGraph;
    private JCheckBox checkBox;
    private List<JButton> buttonsList;
    private JScrollPane scrollPane;
    private JList<String> listSchedules;
    private JScrollPane scrollPaneSchedules;
    private JPanel buttonPanel;

    public ServerMonitoringThread(ServerInformation serverInformation) {
        this.serverInformation = serverInformation;
    }

    @Override
    public void run() {
        serverInformation.updateRailwayMonitoring = true;
        //for text
        frameText.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

        frameText.setBounds(50, 50, 410, 820);
        frameText.getContentPane().setLayout(null);

        lblTitle = new JLabel("Server status textual visualization");
        lblTitle.setBounds(100, 25, 400, 14);
        frameText.getContentPane().add(lblTitle);

        lblUpTime = new JLabel("Up time: " + serverInformation.getUpTime());
        lblUpTime.setBounds(15, 100, 400, 14);
        frameText.getContentPane().add(lblUpTime);

        lblTotalClients = new JLabel("Total clients registered: " + serverInformation.listOfUsers.size());
        lblTotalClients.setBounds(15, 130, 400, 14);
        frameText.getContentPane().add(lblTotalClients);

        lblTotalClientsOnline = new JLabel("Total clients online: " + serverInformation.clientsOnline);
        lblTotalClientsOnline.setBounds(15, 160, 400, 14);
        frameText.getContentPane().add(lblTotalClientsOnline);

        lblTotalNodes = new JLabel("Total nodes: " + serverInformation.middleNodesSockets.size());
        lblTotalNodes.setBounds(15, 190, 400, 14);
        frameText.getContentPane().add(lblTotalNodes);

        lblTotalConnections = new JLabel("Total connections: " + serverInformation.totalConnections());
        lblTotalConnections.setBounds(15, 220, 400, 14);
        frameText.getContentPane().add(lblTotalConnections);

        lblTotalRequests = new JLabel("Total requests: " + serverInformation.totalRequests);
        lblTotalRequests.setBounds(140, 270, 400, 14);
        frameText.getContentPane().add(lblTotalRequests);

        lblTotalLogin = new JLabel("Login requests: " + serverInformation.requestsDetailsCounter.get(RequestsEnum.LOGIN));
        lblTotalLogin.setBounds(15, 300, 400, 14);
        frameText.getContentPane().add(lblTotalLogin);

        lblTotalRegistration = new JLabel("Registration Requests: " + serverInformation.requestsDetailsCounter.get(RequestsEnum.REGISTRATION));
        lblTotalRegistration.setBounds(220, 300, 400, 14);
        frameText.getContentPane().add(lblTotalRegistration);

        lblTotalSuspension = new JLabel("Suspension requests: " + serverInformation.requestsDetailsCounter.get(RequestsEnum.SUSPENDED_TRAFFIC));
        lblTotalSuspension.setBounds(15, 330, 400, 14);
        frameText.getContentPane().add(lblTotalSuspension);

        lblTotalAlteration = new JLabel("Alteration requests: " + serverInformation.requestsDetailsCounter.get(RequestsEnum.LOGIN));
        lblTotalAlteration.setBounds(220, 330, 400, 14);
        frameText.getContentPane().add(lblTotalAlteration);

        lblTotalRailways = new JLabel("Total railways: " + serverInformation.listOfLines.size());
        lblTotalRailways.setBounds(140, 390, 380, 14);
        frameText.getContentPane().add(lblTotalRailways);

        //lines
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));

        scrollPane = new JScrollPane(buttonPanel);
        scrollPane.setPreferredSize(new Dimension(400, 200));
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBounds(15, 410, 360, 300);
        frameText.getContentPane().add(scrollPane);

        btnOpenGraph = new JButton("Open graph");
        btnOpenGraph.setBounds(15, 730, 100, 40);
        btnOpenGraph.setEnabled(false);
        frameText.getContentPane().add(btnOpenGraph);

        checkBox = new JCheckBox("Compact view");
        checkBox.setBounds(270, 730, 120, 40);
        checkBox.setSelected(compactView);
        frameText.getContentPane().add(checkBox);
        checkBox.addActionListener(e -> compactView = !compactView);

        frameText.setVisible(true);

        //for graph
        frameGraph.setBounds(500, 50, 730, 489);
        frameGraph.getContentPane().add(lblIcon);
        frameGraph.setVisible(true);

        //starts the operations thread
        Thread textOperationsLogThread = new Thread(() -> {
            textOperationLogRegistration();
        });
        textOperationsLogThread.start();

        // Execute status log thread
        Thread textStatusLogThread = new Thread(() -> {
            try {
                textStatusLogRegistration(true);
                Thread.sleep(30000);
                while (true) {
                    textStatusLogRegistration(false);
                    Thread.sleep(30000);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        textStatusLogThread.start();

        // Execute graph and the interface thread
        Thread graphicalLogThread = new Thread(() -> {
            try {
                while (true) {
                    graphicInterface();
                    makeGraph();
                    Thread.sleep(1000);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        graphicalLogThread.start();
    }

    /**
     * Method responsible to write the server status in a text file
     */
    private void textStatusLogRegistration(boolean first) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date;
        String logServer;
        date = new Date();

        if (first) {
            logServer = formatter.format(date) + " - Server is up";
            try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("logs/logStatusServer.txt", true)))) {
                out.println(logServer);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        logServer = formatter.format(date) + " - Server Status : " +
                "Clients registered " + serverInformation.listOfUsers.size() + " | " + "Users logged in " + serverInformation.clientsOnline + " | " +
                "Local nodes " + serverInformation.middleNodesSockets.size();
        System.out.println(logServer);

        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("logs/logStatusServer.txt", true)))) {
            out.println(logServer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method responsible to make the registration of operations in a text file
     */
    private void textOperationLogRegistration() {
        while (true) {
            String log = serverInformation.getOperationStringLog();

            if (log != null) {
                System.out.println(log);

                try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("logs/logOperationsServer.txt", true)))) {
                    out.println(log);
                    Thread.sleep(3000);
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //responsible to write the graphic interface with information
    private void graphicInterface() {
        btnOpenGraph.addActionListener(e -> {
            btnOpenGraph.setEnabled(false);
            frameGraph.setVisible(true);
        });

        lblUpTime.setText("Up time: " + serverInformation.getUpTime());
        lblTotalClients.setText("Total clients registered: " + serverInformation.listOfUsers.size());

        lblTotalClients.setText("Total clients registered: " + serverInformation.listOfUsers.size());

        lblTotalClientsOnline.setText("Total clients online: " + serverInformation.clientsOnline);

        lblTotalNodes.setText("Total nodes: " + serverInformation.middleNodesSockets.size());

        lblTotalConnections.setText("Total connections: " + serverInformation.totalConnections());

        lblTotalRequests.setText("Total requests: " + serverInformation.totalRequests);

        lblTotalLogin.setText("Login requests: " + serverInformation.requestsDetailsCounter.get(RequestsEnum.LOGIN));
        lblTotalRegistration.setText("Registration requests: " + serverInformation.requestsDetailsCounter.get(RequestsEnum.REGISTRATION));
        lblTotalSuspension.setText("Suspend requests: " + serverInformation.requestsDetailsCounter.get(RequestsEnum.SUSPENDED_TRAFFIC));
        lblTotalAlteration.setText("Alteration requests: " + serverInformation.requestsDetailsCounter.get(RequestsEnum.SCHEDULE_ALTERATION));

        lblTotalRailways.setText("Total railways: " + serverInformation.listOfLines.size());

        //lines
        if (serverInformation.updateRailwayMonitoring) {
            buttonPanel.removeAll();
            buttonPanel.revalidate();
            buttonPanel.repaint();

            // Create an array of buttons
            Line[] lines = serverInformation.listOfLines.values().toArray(new Line[0]);
            List<String> items = new ArrayList<>();

            //prepare the buttons

            buttonsList = new ArrayList<>();
            for (Line line : lines) {
                items.add(line.getName());
                JButton button = new JButton(line.getName());
                buttonsList.add(button);
                button.addActionListener(e -> {
                            JOptionPane.showMessageDialog(null, line.getSchedulesString(),
                                    "Schedules of " + line.getName(), JOptionPane.INFORMATION_MESSAGE);
                        }
                );
                buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                buttonPanel.add(button);
            }

            // Create the scroll pane and add the panel to it
            serverInformation.updateRailwayMonitoring = false;
        }
    }

    /**
     * Responsible to shows the status graph of server.
     */
    private void makeGraph() throws InterruptedException {
        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("strict graph{\n");

        //if there is no middle nodes connected
        if (serverInformation.middleNodesSockets.size() == 0) {
            stringBuilder.append("Server\n}");
            this.makeDotAndPng(stringBuilder.toString(), "server_status");
            return;
        }

        //if there is middle nodes connected
        MiddleNodeStatistics[] nodeStatistics = serverInformation.middleNodeStatistics.values().toArray(new MiddleNodeStatistics[0]);
        for (MiddleNodeStatistics node : nodeStatistics) {
            stringBuilder
                    .append("\tServer -- ")
                    .append("\"" + node.hashCode() + "\"")
                    .append("\n");
        }
        for (MiddleNodeStatistics node : nodeStatistics) {
            if (compactView) {
                stringBuilder
                        .append("\"" + node.hashCode() + "\"")
                        .append(" [label=\"" + node.host + ":" + node.tcpPort + "\n")
                        .append("Clients: " + node.totalClientsOnline + "\n")
                        .append("Admins: " + node.totalAdminsOnline + "\n")
                        .append("Moderators: " + node.totalModeratorsOnline + "\n")
                        .append("Connections: " + node.totalConnections + "\n")
                        .append("Total requests: " + node.totalRequests + "\n")
                        .append("Up time: " + node.getUpTime() + "\"];\n");
            } else {
                stringBuilder
                        .append("\"" + node.hashCode() + "\"")
                        .append(" [label=\"" + node.host + ":" + node.tcpPort + "\n")
                        .append("Total requests: " + node.totalRequests + "\n")
                        .append("Up time: " + node.getUpTime() + "\"];\n");

                stringBuilder.append("\"" + node.hashCode() + "\"" + " -- ")
                        .append("\"" + node.tcpPort + node.hashCode() + "\nAdmins" + " : " + node.totalAdminsOnline + "\"");

                stringBuilder.append("\"" + node.hashCode() + "\"" + " -- ")
                        .append("\"" + node.tcpPort + node.hashCode() + "\nClients" + " : " + node.totalClientsOnline + "\"");

                stringBuilder.append("\"" + node.hashCode() + "\"" + " -- ")
                        .append("\"" + node.tcpPort + node.hashCode() + "\nModerators" + " : " + node.totalModeratorsOnline + "\"");

                stringBuilder.append("\"" + node.hashCode() + "\"" + " -- ")
                        .append("\"" + node.tcpPort + node.hashCode() + "\nConnections" + " : " + node.totalConnections + "\"");
            }
        }

        stringBuilder.append("}");
        this.makeDotAndPng(stringBuilder.toString(), "server_status");
    }

    /**
     * Creates a .dot file and a png image based on dot file, by executing the command "dot -Tpng 'filename' -O.
     *
     * @param contentString String of .dot content.
     * @param filename      File name of dot document to be created
     * @throws InterruptedException will be thrown if user machine doesn't have dot installed on his machine.
     * @implNote process based on documentation of dot shell.
     */
    private void makeDotAndPng(String contentString, String filename) throws InterruptedException {
        //Make and export a .dot file
        try {
            FileWriter myWriter = new FileWriter(this.directory + "/" + filename + ".dot");
            myWriter.write(contentString);
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        /*
        Creates and png image based on dot file, by executing the command
        If the user machine doesn't have dot installed, will be thrown a exception.
         */
        String dotFileName = this.directory + "/" + filename + ".dot";
        try {
            String[] c = {"dot", "-Tpng", dotFileName, "-O"}; //command to execute
            Process p = Runtime.getRuntime().exec(c);
            int err = p.waitFor();
        } catch (IOException | InterruptedException e1) {
            graphVizSupported = false;
            System.err.println("Graphviz not supported");
        }
        showImage(dotFileName + ".png");
    }


    /**
     * Shows an image in a graphical frame.
     *
     * @param imgPath path to image. Needs to contain the full name of image, eg: "docs/image.png"
     */
    private void showImage(String imgPath) {
        try {
            frameGraph.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    btnOpenGraph.setEnabled(true);
                }
            });
            if (!graphVizSupported) {
                if (graphViErrorCounter == 0) {
                    //if graph viz is not supported show alert
                    graphViErrorCounter++;
                    JOptionPane.showMessageDialog(null,
                            "For the graph operation it's fundamental to have graphviz (.dot) installed in the machine" +
                                    "\nDownload link: https://graphviz.org/download/\"",
                            "Feature not supported in this machine",
                            JOptionPane.ERROR_MESSAGE);
                }
            } else {
                BufferedImage img = ImageIO.read(new File(imgPath));
                ImageIcon icon = new ImageIcon(img);
                frameGraph.setLayout(new FlowLayout());
                if (img.getWidth() < 500) {
                    frameGraph.setSize(500, 500);
                } else {
                    frameGraph.setSize(img.getWidth() + 100, img.getHeight() + 100);
                }
                //graph
                lblIcon.setIcon(icon);
            }
        } catch (IOException e) {
            graphVizSupported = false;
            System.err.println("Graphviz not supported");
        }
    }
}