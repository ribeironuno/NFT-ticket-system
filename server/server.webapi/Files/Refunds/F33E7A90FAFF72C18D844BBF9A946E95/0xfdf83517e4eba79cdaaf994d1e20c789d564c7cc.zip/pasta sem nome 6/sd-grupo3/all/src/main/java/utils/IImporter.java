package utils;

import centralnode.ServerInformation;
import model.Line;
import model.User;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.util.HashMap;

public interface IImporter {

    /**
     * Given a directory imports the settings about the server.
     */
    ServerInformation importServiceSettings(String directoryFile) throws IOException, ParseException;

    /**
     * Given a directory import the passenger information.
     */
    HashMap<String, User> importUsersInformation(String directoryFile) throws IOException, ParseException;


    /**
     * Given a directory import the lines information of the network
     */
    HashMap<String, Line> importLinesInformation(String directoryFile) throws IOException, ParseException;
}
