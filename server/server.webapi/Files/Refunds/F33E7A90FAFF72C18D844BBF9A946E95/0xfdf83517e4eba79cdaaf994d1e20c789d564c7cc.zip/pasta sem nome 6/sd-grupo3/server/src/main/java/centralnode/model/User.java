package centralnode.model;

import common.implementation.*;
import common.interfaces.*;

import java.io.Serializable;
import java.util.List;

public class User implements Serializable {

    private String email;
    private String password;
    private String name;
    private RoleEnum role;
    private List linesAssociated;
    private Boolean online;

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    public RoleEnum getRole() {
        return role;
    }

    public List getLinesAssociated() {
        return linesAssociated;
    }

    public void setOnline(Boolean online) {
        this.online = online;
    }

    @Override
    public String toString() {
        return "User{" +
                "email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                ", role=" + role +
                ", linesAssociated=" + linesAssociated +
                ", online=" + online +
                '}';
    }

    public User(String email, String password, String name, List linesAssociated) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.linesAssociated = linesAssociated;
        this.role = RoleEnum.PASSENGER;
        this.online = false;
    }

    public User(String email, String password, String name, RoleEnum role) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.linesAssociated = null;
        this.role = role;
        this.online = false;
    }

    //create a user of type passenger from the registration information
    public User(Request.RegistrationInformation registrationInformation) {
        this.email = registrationInformation.getEmail();
        this.password = registrationInformation.getPassword();
        this.name = registrationInformation.getName();
        this.role = RoleEnum.PASSENGER;
        this.linesAssociated = registrationInformation.getLinesAssociated();
        this.online = false;
    }

    //create a back-office from the registration information
    public User(Request.RegistrationInformationBackOffice RegistrationInformationBackOffice, RoleEnum role) {
        this.email = RegistrationInformationBackOffice.getEmail();
        this.password = RegistrationInformationBackOffice.getPassword();
        this.name = RegistrationInformationBackOffice.getName();
        this.role = role;
        this.linesAssociated = null;
        this.online = false;
    }
}
