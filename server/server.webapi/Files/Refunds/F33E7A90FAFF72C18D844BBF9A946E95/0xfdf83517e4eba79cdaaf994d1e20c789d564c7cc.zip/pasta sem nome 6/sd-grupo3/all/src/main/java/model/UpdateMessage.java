package model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

public class UpdateMessage implements Serializable {
    public HashMap<String, Line> lines;

    public UpdateMessage(HashMap<String, Line> lines){
        this.lines = lines;
    }
}
