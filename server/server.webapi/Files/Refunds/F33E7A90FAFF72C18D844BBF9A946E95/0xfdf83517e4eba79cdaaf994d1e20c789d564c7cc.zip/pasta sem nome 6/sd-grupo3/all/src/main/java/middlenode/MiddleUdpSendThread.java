package middlenode;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * Thread responsible to be sending to all clients by UDP protocol the not critical important messages
 */
public class MiddleUdpSendThread extends Thread {

    private MiddleNodeInfo middleNodeInfo;
    private DatagramSocket udpSocket;

    public MiddleUdpSendThread(DatagramSocket udpSocket, MiddleNodeInfo middleNodeInfo) {
        this.middleNodeInfo = middleNodeInfo;
        this.udpSocket = udpSocket;
    }

    @Override
    public void run() {
        while (true) {
            try {
                String sendMsg = middleNodeInfo.broadcastMessages.poll();
                if (sendMsg != null) {
                    String totalMsg = "Broadcast UDP: " + sendMsg;
                    byte[] bytesToSend = totalMsg.getBytes(StandardCharsets.UTF_8);
                    //sends to all clients registered to receive broadcast
                    for (Map.Entry<InetAddress, List<Integer>> entry : middleNodeInfo.ipAndPortToBroadcast.entrySet()) {
                        List<Integer> ports = entry.getValue();
                        InetAddress ip = entry.getKey();
                        //for each port in the ip
                        for (Integer port : ports) {
                            DatagramPacket sendPacket = new DatagramPacket(bytesToSend, bytesToSend.length, ip, port);
                            udpSocket.send(sendPacket);
                        }
                    }
                }
                Thread.sleep(1000);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
