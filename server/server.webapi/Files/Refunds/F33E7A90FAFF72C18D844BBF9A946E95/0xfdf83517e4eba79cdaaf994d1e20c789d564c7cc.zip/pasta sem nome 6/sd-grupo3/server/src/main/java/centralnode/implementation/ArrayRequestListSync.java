package centralnode.implementation;

import common.implementation.*;
import common.interfaces.*;

import java.io.Serializable;
import java.util.PriorityQueue;

/**
 * Implementation of sync list in array list
 *
 */
public class ArrayRequestListSync implements Serializable {

    PriorityQueue<Request> queue = new PriorityQueue<>(20, Request::compareTo);

    public synchronized void add(Request toAdd) {
        queue.add(toAdd);
    }

    public synchronized Request get(){
        return queue.poll();
    }

    public synchronized int size() {
        return queue.size();
    }
}
