package centralnode.implementation;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Thread that will abstract from clients all different ports of middle nodes.
 * <p>
 * This thread will for each client's request verify what is the middle node server with less client's sockets
 * connected and write back to the client socket that port, in order to distribute the work equal for all distributed
 * middle nodes.
 */
public class ServerGateway extends Thread {
    public ServerInformation serverInformation;
    private int gatewayPort;

    public ServerGateway(int port, ServerInformation serverInformation) {
        this.serverInformation = serverInformation;
        this.gatewayPort = port;
    }

    //Searches for best port in the current local nodes
    private String getBestPort() {
        MiddleNodeStatistics[] listOfNodes = serverInformation.middleNodeStatistics.values().toArray(new MiddleNodeStatistics[0]);

        int minPort = listOfNodes[0].tcpPort;
        int udpPort = listOfNodes[0].udpPort;
        int minClients = listOfNodes[0].totalConnections;

        for (MiddleNodeStatistics localNode : listOfNodes) {
            if (localNode.totalConnections < minClients) {
                minPort = localNode.tcpPort;
                udpPort = localNode.udpPort;
            }
        }
        return minPort + " " + udpPort;
    }

    @Override
    public void run() {
        try {
            System.out.println("Gateway is up on port: " + gatewayPort);
            ServerSocket serverSocket = new ServerSocket(gatewayPort);

            while (true) {
                //waits for the client
                Socket clientSocket = serverSocket.accept();

                //writer to client
                PrintWriter outToClient = new PrintWriter(clientSocket.getOutputStream(), true);

                //sends the best port
                if (serverInformation.middleNodesSockets.size() == 0) {
                    outToClient.println("At the moment there is no ports to connect");
                } else {
                    // "TCP_PORT + UDP_PORT"
                    outToClient.println(getBestPort());
                }
            }
        } catch (IOException e) {
            System.err.println("Could not set gateway on port: " + gatewayPort);
            System.exit(-1);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Something went wrong setting up the gateway in port : " + gatewayPort);
            System.exit(-1);
        }
    }
}
