package middlenode;

import model.*;

import java.net.InetAddress;
import java.net.Socket;
import java.util.*;

/**
 * Class that contains all information about a one single node.
 */
public class MiddleNodeInfo {
    public int tcpPort;
    public int udpPort;

    public String host;
    //hash code socket, email
    public HashMap<Integer, String> onlineClients;

    public HashMap<Integer, Socket> codeSocketsAdmin;

    public HashMap<Integer, Socket> codeSocketsLocalManager;

    public HashMap<Integer, Socket> localSocketsConnections = new HashMap<>();

    protected HashMap<Line, ArrayList<Socket>> clientsPerLine;

    public boolean isSuspended;

    protected HashMap<String, Line> lines;

    //associate ips to ports. The systems know how much ips and how many ports are listening
    protected HashMap<InetAddress, List<Integer>> ipAndPortToBroadcast = new HashMap<>();

    protected Queue<String> broadcastMessages = new PriorityQueue<>();

    public MiddleNodeInfo(int tcpPort, int udpPort, String host) {
        this.tcpPort = tcpPort;
        this.host = host;
        this.udpPort = udpPort;
        this.codeSocketsAdmin = new HashMap<>();
        this.codeSocketsLocalManager = new HashMap<>();
        this.onlineClients = new HashMap<>();
        this.lines = new HashMap<>();
        this.clientsPerLine = new HashMap<>();
    }

    public HashMap<String, Line> getLines() {
        return lines;
    }

    public HashMap<Integer, Socket> getCodeSocketsAdmin() {
        return codeSocketsAdmin;
    }

    public HashMap<Integer, Socket> getCodeSocketsLocalManager() {
        return codeSocketsLocalManager;
    }

}
