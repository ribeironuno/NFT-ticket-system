package centralnode.implementation;

import java.time.Duration;
import java.time.LocalDateTime;

/**
 * Will contain all statistics about a middle node.
 */
public class MiddleNodeStatistics {

    public int socketHashCode;

    public int tcpPort;

    public int udpPort;

    public int totalConnections = 0;

    public int totalClientsOnline = 0;

    String host;

    public int totalAdminsOnline = 0;

    public int totalModeratorsOnline = 0;

    public int totalRequests = 0;

    public LocalDateTime upDateTime;

    public MiddleNodeStatistics(int socketHashCode, int tcpPort, String host, int udpPort) {
        this.tcpPort = tcpPort;
        this.host = host;
        this.socketHashCode = socketHashCode;
        this.upDateTime = LocalDateTime.now();
        this.udpPort = udpPort;
    }

    public String getUpTime() {
        Duration duration = Duration.between(this.upDateTime, LocalDateTime.now());
        long days = duration.toDays();
        long hours = duration.toHours() % 24;
        long minutes = duration.toMinutes() % 60;
        long seconds = duration.toSeconds() % 60;

        // Format the result as a string
        return String.format("%d:%02d:%02d:%02d", days, hours, minutes, seconds);
    }
}
