package centralnode.implementation;

import common.implementation.*;
import common.interfaces.*;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Class that will update the middle node with the server information
 */
public class ServerMiddleUpdateThread extends Thread {

    private final Socket updateSocket;
    private ServerInformation serverInformation;

    public ServerMiddleUpdateThread(Socket updateSocket, ServerInformation serverInformation) {
        this.updateSocket = updateSocket;
        this.serverInformation = serverInformation;
    }

    @Override
    public void run() {
        try {
            //while there is connection between server and middle
            while (!updateSocket.isClosed()) {
                UpdateMessage updateMessage = new UpdateMessage(serverInformation.listOfLines);

                ObjectOutputStream outToMiddle = new ObjectOutputStream(updateSocket.getOutputStream());
                outToMiddle.writeObject(updateMessage);

                Thread.sleep(1000);
            }
        } catch (IOException | InterruptedException e) {
            System.err.println("Middle node " + updateSocket.getLocalAddress() + ":" + updateSocket.getPort() + " update thread stopped");
        }
    }
}
