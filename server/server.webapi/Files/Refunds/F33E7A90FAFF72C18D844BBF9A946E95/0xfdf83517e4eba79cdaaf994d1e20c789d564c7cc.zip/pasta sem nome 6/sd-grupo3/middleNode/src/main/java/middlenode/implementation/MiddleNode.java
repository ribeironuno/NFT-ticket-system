package middlenode.implementation;


import common.implementation.UpdateMessage;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Class that will init the middle server node
 */
public class MiddleNode {
    public static void main(String[] args) {
        //information about the server
        UpdateMessage serverInformation = new UpdateMessage(new HashMap<>());

        //ports where this server will go up to clients
        int THIS_TCP_PORT = 2014;
        int THIS_UDP_PORT = THIS_TCP_PORT + 3000;

        //information about this specific node
        MiddleNodeInfo middleNodeInfo = new MiddleNodeInfo(THIS_TCP_PORT, THIS_UDP_PORT, "localhost");

        //ports to connect to the server
        String SERVER_HOST = "localhost";
        int SERVER_PORT = 2000;
        int UPDATE_PORT = 1999;
        int SYNC_PORT = 1998;

        //list of thread that handle the connection (middle node <- client)
        List<MiddleClientThread> clientThreads = new ArrayList<>();

        ServerSocket localServerSocket;
        DatagramSocket udpSocket;
        try {
            System.out.println("Middle node (" + middleNodeInfo.tcpPort + ") thread started!");
            //create connection with server
            Socket socketWithServer = new Socket(SERVER_HOST, SERVER_PORT);
            Socket socketWithServerUpdate = new Socket(SERVER_HOST, UPDATE_PORT);

            //create server to passengers connect
            localServerSocket = new ServerSocket(middleNodeInfo.tcpPort);
            System.out.println("New middle node server hosted in " + middleNodeInfo.tcpPort);

            //create broadcast server to send not critical messages
            udpSocket = new DatagramSocket(middleNodeInfo.udpPort, InetAddress.getByName(middleNodeInfo.host));

            //starts the thread that will be sending the UDP broadcast to the users
            MiddleUdpSendThread middleUdpSendThread = new MiddleUdpSendThread(udpSocket, middleNodeInfo);
            middleUdpSendThread.start();

            //starts the thread that will be receiving the UDP requests to "follow" to UDP broadcast
            MiddleUdpReceiveThread middleUdpReceiveThread = new MiddleUdpReceiveThread(udpSocket, middleNodeInfo);
            middleUdpReceiveThread.start();

            //communicate to the server the port that this middle node will be listening
            PrintWriter outToServer = new PrintWriter(socketWithServer.getOutputStream(), true);
            outToServer.println(middleNodeInfo.host + " " + middleNodeInfo.tcpPort + " " + middleNodeInfo.udpPort);

            //start monitoring thread
            MiddleNodeMonitoring nodeMonitoringThread = new MiddleNodeMonitoring(middleNodeInfo, serverInformation);
            nodeMonitoringThread.start();

            //thread that is listening to server's input and will communicate with all sockets (server -> middle node -> clients)
            MiddleServerThread middleServerThread = new MiddleServerThread(
                    socketWithServer,
                    serverInformation,
                    middleNodeInfo
            );
            middleServerThread.start();

            //thread that will listen to server updates
            MiddleServerUpdateThread middleServerUpdateThread = new MiddleServerUpdateThread(
                    socketWithServerUpdate,
                    middleNodeInfo
            );
            middleServerUpdateThread.start();

            InetAddress serverAddress = InetAddress.getByName(SERVER_HOST);
            //thread that will listen to server updates
            MiddleSyncClockThread middleSyncClockThread = new MiddleSyncClockThread(
                    SYNC_PORT,
                    SERVER_HOST,
                    new DatagramSocket(), serverAddress
            );

            middleSyncClockThread.start();

            while (true) {
                //new client arrived
                Socket newClient = localServerSocket.accept();
                middleNodeInfo.localSocketsConnections.put(newClient.hashCode(), newClient);

                //thread that will handle the connections (middle node <- client) with objective to send request to server
                MiddleClientThread middleClientThread = new MiddleClientThread(socketWithServer, newClient, middleNodeInfo);
                middleClientThread.start();
                clientThreads.add(middleClientThread);
            }
        } catch (IOException e) {
            System.err.println("Some problem happened starting the middle node server.\nVerify if the server is up and if the server port is correct and if there is not programm using the samer port");
            e.printStackTrace();
            System.exit(-1);
        }
    }
}
