package centralnode;

import org.json.simple.parser.ParseException;
import utils.ServerImporter;

import java.io.IOException;

public class ServerReadLinesFile extends Thread {
    ServerInformation serverInformation;

    public ServerReadLinesFile(ServerInformation serverInformation) {
        this.serverInformation = serverInformation;
    }

    @Override
    public void run() {
        ServerImporter importer = new ServerImporter();
        try {
            this.serverInformation.listOfLines = importer.importLinesInformation("docs/lines.json");
        } catch (IOException e) {
            System.err.println("Error reaching the lines file! Verify the location");
            System.exit(-1);
        } catch (ParseException e) {
            System.err.println("Error parsing the file! Verify the content of lines file!");
            System.exit(-1);
        }
    }
}
