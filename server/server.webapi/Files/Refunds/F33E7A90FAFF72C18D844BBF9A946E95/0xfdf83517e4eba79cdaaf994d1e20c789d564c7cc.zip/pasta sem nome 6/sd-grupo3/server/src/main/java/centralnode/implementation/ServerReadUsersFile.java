package centralnode.implementation;

import org.json.simple.parser.ParseException;
import utils.ServerImporter;

import java.io.IOException;

/**
 * Responsible to read users
 */
public class ServerReadUsersFile extends Thread {
    ServerInformation serverInformation;

    public ServerReadUsersFile(ServerInformation serverInformation) {
        this.serverInformation = serverInformation;
    }

    @Override
    public void run() {
        ServerImporter importer = new ServerImporter();
        try {
            this.serverInformation.listOfUsers = importer.importUsersInformation("docs/users.json");
        } catch (IOException e) {
            System.err.println("Error reaching the users file! Verify the location");
            System.exit(-1);
        } catch (ParseException e) {
            System.err.println("Error parsing the file! Verify the content of users file!");
            System.exit(-1);
        }
    }
}
