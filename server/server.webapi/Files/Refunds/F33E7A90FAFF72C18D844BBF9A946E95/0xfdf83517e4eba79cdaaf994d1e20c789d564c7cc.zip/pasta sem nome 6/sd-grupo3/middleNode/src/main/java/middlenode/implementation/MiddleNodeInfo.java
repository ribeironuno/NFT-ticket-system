package middlenode.implementation;

import common.implementation.Line;

import java.net.InetAddress;
import java.net.Socket;
import java.util.*;

/**
 * Class that contains all information about a one single node.
 * <p>
 * It's safe to make all variables protected.
 */
public class MiddleNodeInfo {
    //tcp port with clients
    protected int tcpPort;
    //udp port with clients
    protected int udpPort;
    //host
    protected String host;

    //to keep tracking of online clients
    protected HashMap<Integer, String> onlineClients;
    //to keep tracking of online clients
    protected HashMap<Integer, Socket> codeSocketsAdmin;
    //to keep tracking of online clients
    protected HashMap<Integer, Socket> codeSocketsLocalManager;
    //to keep tracking of online clients
    protected HashMap<Integer, Socket> localSocketsConnections = new HashMap<>();
    //to keep tracking of how many clients by line
    protected HashMap<Line, ArrayList<Socket>> clientsPerLine;

    protected boolean isSuspended;
    //lines
    protected HashMap<String, Line> lines;

    //associate ips to ports. The systems know how much ips and how many ports are listening
    protected HashMap<InetAddress, List<Integer>> ipAndPortToBroadcast = new HashMap<>();

    protected Queue<String> broadcastMessages = new PriorityQueue<>();

    public MiddleNodeInfo(int tcpPort, int udpPort, String host) {
        this.tcpPort = tcpPort;
        this.host = host;
        this.udpPort = udpPort;
        this.codeSocketsAdmin = new HashMap<>();
        this.codeSocketsLocalManager = new HashMap<>();
        this.onlineClients = new HashMap<>();
        this.lines = new HashMap<>();
        this.clientsPerLine = new HashMap<>();
    }
}
