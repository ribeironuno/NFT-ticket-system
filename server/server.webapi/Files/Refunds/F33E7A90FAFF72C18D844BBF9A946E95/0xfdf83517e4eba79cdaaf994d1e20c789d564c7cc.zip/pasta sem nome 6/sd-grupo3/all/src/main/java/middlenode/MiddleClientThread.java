package middlenode;

import model.Line;
import model.Request;
import model.RequestsEnum;
import model.Schedule;
import model.RoleEnum;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * Will be listening one client and send the message to the server. (client -> middle node -> server)
 * Will cast the user input into a Request type in order to server understands it and prepare it
 */
public class MiddleClientThread extends Thread {
    //socket with the central server
    private final Socket socketCentral;
    //socket with client
    private final Socket socketClient;
    //the information about the middle node (information about it self)
    private MiddleNodeInfo middleNodeInfo;

    public MiddleClientThread(Socket socketCentral, Socket socketClient, MiddleNodeInfo middleNodeInfo) {
        this.socketCentral = socketCentral;
        this.socketClient = socketClient;
        this.middleNodeInfo = middleNodeInfo;
    }

    @Override
    public void run() {
        try {
            String msgFromClient;
            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(this.socketClient.getInputStream()));
            PrintWriter writerToClient = new PrintWriter(this.socketClient.getOutputStream(), true);

            //alert server from a new connection
            ObjectOutputStream writerNewConnection = new ObjectOutputStream(socketCentral.getOutputStream());
            Request requestNewConnection = new Request(this.middleNodeInfo.hashCode(), middleNodeInfo.tcpPort,
                    "server", RequestsEnum.NEW_CONNECTION, null);
            writerNewConnection.writeObject(requestNewConnection);

            //keeps listening until socket is closed
            while (!socketClient.isClosed() && (msgFromClient = inFromClient.readLine()) != null) {

                if (msgFromClient.equals("help")) {
                    writerToClient.println("----------------------- Main operations -----------------------");
                    writerToClient.println("Register passenger-> registration <email> <name> <password> <lines>\n   You can send multiple lines in the process, just leave a space between them");
                    writerToClient.println("Register admin -> admin <email> <name> <password> <secret>");
                    writerToClient.println("Register local manager -> localManager <email> <name> <password> <secret>\n");
                    writerToClient.println("Login -> login <email> <password>");
                    writerToClient.println("Logout -> logout");
                    writerToClient.println("See lines associated -> mylines");
                    writerToClient.println("Associate a new line -> add <line>");
                    writerToClient.println("Dissociate to a line -> remove <line>");
                    writerToClient.println("Report feedback -> report <line> <comment>");
                    writerToClient.println("End application -> bye\n");
                    writerToClient.println("------------------------------ Info operations --------------------------");
                    writerToClient.println("To see all existent lines -> lines");
                    writerToClient.println("To see schedules about one or more lines -> schedules <line>\n   You can check multiple schedules, just leave a space between lines or type only one\n");
                    writerToClient.println("------------------ Only Local manager and Admin ----------------");
                    writerToClient.println("Warn schedule alteration -> alteration <line> <schedule> <new-schedule>\n    You can send multiple lines in the process, just leave a space between them");
                    writerToClient.println("Suspend the network -> suspend");
                    writerToClient.println("Unsuspend the network -> unsuspend\n");
                    writerToClient.println("---------------------------- Only Admin ------------------------");
                    writerToClient.println("Add a line -> line add <line> <schedule>\n    You can add multiple schedules, but one it's required, minimum. Schedule examples: 09h30 10h21 23h59");
                    writerToClient.println("Remove a line  -> line remove <line>");
                    writerToClient.println("Add a schedule to a line  -> line schedule add <line> <schedule>\n    Supports multiple schedules");
                    writerToClient.println("Remove a schedule from a line  -> line schedule remove <line> <schedule>\n   You can delete multiple. If all schedules deleted the line will be deleted too\n");
                } else if (msgFromClient.equals("lines")) {
                    writerToClient.println("---------------------- Existent lines ----------------------");
                    printLinesToClient(writerToClient);
                } else if (msgFromClient.matches("^schedules .*$")) {
                    writerToClient.println("---------------------- Schedules lines ---------------------");
                    printSchedulesToClient(writerToClient, msgFromClient);
                } else if (msgFromClient.equals("mylines")) {
                    printClientLines(writerToClient);
                } else {
                    Request request = prepareRequest(msgFromClient, this.socketClient.hashCode(), writerToClient);
                    if (request != null) {
                        ObjectOutputStream writer = new ObjectOutputStream(socketCentral.getOutputStream());
                        writer.writeObject(request);
                    }
                }
            }

        } catch (IOException e) {
            //check if was a brute force close and make the logout
            if (checkIsLoginIn(this.socketClient.hashCode())) {
                //removes the client from the online clients
                middleNodeInfo.onlineClients.remove(this.socketClient.hashCode());
                logoutClient(this.socketClient.hashCode());

                //get role of client
                RoleEnum role = checkSocketPermission(this.socketClient.hashCode());
                if (checkSocketPermission(this.socketClient.hashCode()) != RoleEnum.PASSENGER) {
                    logoutBackOfficeUser(this.socketClient.hashCode(), role);
                }
                Request request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.LOGOUT, role);
                ObjectOutputStream writer = null;
                //sends to the server the request
                try {
                    writer = new ObjectOutputStream(socketCentral.getOutputStream());
                    writer.writeObject(request);
                } catch (IOException ex) {
                    System.err.println("Error trying to logout a force exit client ");
                }
            }
            Request request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.EXIT, null);
            ObjectOutputStream writer = null;
            //sends to the server the request
            try {
                writer = new ObjectOutputStream(socketCentral.getOutputStream());
                writer.writeObject(request);
            } catch (IOException ex) {
                System.err.println("Error trying to logout a force exit client ");
            }
            //removes the client from the connections
            this.middleNodeInfo.localSocketsConnections.remove(this.socketClient.hashCode());
            System.out.println("User disconnected");
        }
    }

    /**
     * Will receive a bunch of information and will create a Request object that is the common type of communication
     * between this two parts (server and middle node)
     */
    private Request prepareRequest(String messageFromClient, int clientSocket, PrintWriter writerToClient) throws IOException {
        Request request = null;

        //LOGIN
        if (messageFromClient.matches("^login [a-zA-Z0-9]+@[a-zA-Z0-9]+.[a-zA-Z0-9]+ [a-zA-Z0-9!@_-]+$")) {
            //check if user is not already logged
            if (!checkIsLoginIn(clientSocket)) {
                String[] loginInformation = messageFromClient.split(" ");
                if (loginInformation.length == 3) {
                    request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.LOGIN,
                            new Request.LoginInformation(loginInformation[1], loginInformation[2]));
                }
            } else {
                writerToClient.println("You already have logged in!");
            }

            //REGISTRATION
        } else if (messageFromClient.matches("^registration [a-zA-Z0-9]+@[a-zA-Z0-9]+.[a-zA-Z0-9]+ [a-zA-Z]+ [a-zA-Z0-9!@_-]+($|(( ([a-zA-Z_-])+)+([a-zA-Z_-])$))")) {

            if (!checkIsLoginIn(clientSocket)) {
                String[] registrationInformation = messageFromClient.split(" ");
                List<String> linesNames = new ArrayList<>();
                for (int i = 4; i < registrationInformation.length; i++) {
                    if (this.middleNodeInfo.lines.containsKey(registrationInformation[i])) {
                        linesNames.add(registrationInformation[i]);
                    }
                }

                //check if the all lines sent by client exist
                if (linesNames.size() == (registrationInformation.length - 4)) {
                    request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.REGISTRATION,
                            new Request.RegistrationInformation(registrationInformation[1], registrationInformation[2], registrationInformation[3], linesNames));
                } else {
                    writerToClient.println("You have sent lines that doesn't exists! Write lines to see all the available lines");
                }
            } else {
                writerToClient.println("Logout before make a registration!");
            }

            //LINE ADD (ADMIN ONLY)
        } else if (messageFromClient.matches("^line add ([a-zA-Z_]+)-([a-zA-Z_]+) (\\d\\dh\\d\\d)+($| \\d\\dh\\d\\d)")){
            //verifies the permisson of client
            if (checkSocketPermission(clientSocket) == RoleEnum.ADMIN) {
                String[] addLineSplit = messageFromClient.split(" ");
                String lineName = addLineSplit[2];
                //if line already exists
                if (middleNodeInfo.lines.containsKey(lineName)) {
                    writerToClient.println("Already exists a line with that name");
                } else {
                    String[] schedules = Arrays.copyOfRange(addLineSplit, 3, addLineSplit.length);
                    Line line = new Line(lineName);

                    line.addScheduleList(createListOfSchedules(schedules));

                    request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.ADD_LINE,
                            new Request.SingleLineInformation(line));
                }
            } else {
                writerToClient.println("You don't have permission to execute this command!");
            }

            //LINE REMOVE (ADMIN ONLY)
        } else if (messageFromClient.matches("^line remove ([a-zA-Z_]+)-([a-zA-Z_]+)$")) {
            if (checkSocketPermission(clientSocket) == RoleEnum.ADMIN) {
                String[] addLineSplit = messageFromClient.split(" ");
                String lineName = addLineSplit[2];
                //if line already exists
                if (!middleNodeInfo.lines.containsKey(lineName)) {
                    writerToClient.println("There isn't lines with that name! Type lines to view all lines");
                } else {
                    Line line = new Line(lineName);
                    request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.REMOVE_LINE,
                            new Request.SingleLineInformation(line));
                }
            } else {
                writerToClient.println("You don't have permission to execute this command!");
            }

            //ADD A SCHEDULE TO A LINE (ADMIN ONLY)
        } else if (messageFromClient.matches("^line schedule add ([a-zA-Z_]+)-([a-zA-Z_]+) (\\d\\dh\\d\\d)+($| \\d\\dh\\d\\d)+$")) {
            if (checkSocketPermission(clientSocket) == RoleEnum.ADMIN) {
                String[] lineSplit = messageFromClient.split(" ");
                String lineName = lineSplit[3];
                //if line already exists
                if (!middleNodeInfo.lines.containsKey(lineName)) {
                    writerToClient.println("There isn't a line with that name");
                } else {
                    String[] schedules = Arrays.copyOfRange(lineSplit, 4, lineSplit.length);

                    List<Schedule> schedulesToAdd = createListOfSchedules(schedules);
                    Line tmpLine = this.middleNodeInfo.lines.get(lineName);

                    if (!tmpLine.checkSchedulesExists(schedulesToAdd)) {
                        request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.ADD_SCHEDULE,
                                new Request.SchedulesInformation(lineName, schedulesToAdd));
                    } else {
                        writerToClient.println("One or more schedule are already associated with that line! Check the existent schedules ");
                    }
                }
            } else {
                writerToClient.println("You don't have permission to execute this command!");
            }

            //ASSOCIATE A LINE TO A USER
        } else if (messageFromClient.matches("^add [a-zA-Z_-]+($|( [a-zA-Z_-]+)+$)")) {
            String[] lineSplit = messageFromClient.split(" ");
            List<Line> lines = new ArrayList<>();
            //if line already exists
            if (checkIsLoginIn(clientSocket) && checkSocketPermission(clientSocket) == RoleEnum.PASSENGER) {
                for (int i = 1; i < lineSplit.length; i++) {
                    if (middleNodeInfo.lines.containsKey(lineSplit[i])) {
                        lines.add(middleNodeInfo.lines.get(lineSplit[i]));
                    }
                }
                if (lines.size() == lineSplit.length - 1) {
                    request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.ASSOCIATE_LINE,
                            new Request.LinesEmail(lines, middleNodeInfo.onlineClients.get(socketClient.hashCode()), null));
                } else {
                    writerToClient.println("Line(s) sent doesn't exists!");
                }
            } else {
                writerToClient.println("Login as a passenger first!");
            }

            //REMOVE A LINE ASSOCIATED AT ONE USER
        } else if (messageFromClient.matches("^remove [a-zA-Z_-]+($|( [a-zA-Z_-]+)+$)")) {
            String[] lineSplit = messageFromClient.split(" ");
            List<Line> lines = new ArrayList<>();
            //if line already exists
            if (checkIsLoginIn(clientSocket) && checkSocketPermission(clientSocket) == RoleEnum.PASSENGER) {
                for (int i = 1; i < lineSplit.length; i++) {
                    if (middleNodeInfo.lines.containsKey(lineSplit[i])) {
                        lines.add(middleNodeInfo.lines.get(lineSplit[i]));
                    }
                }
                if (lines.size() == lineSplit.length - 1) {
                    request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.DISSOCIATE_LINE,
                            new Request.LinesEmail(lines, middleNodeInfo.onlineClients.get(socketClient.hashCode()), null));
                } else {
                    writerToClient.println("Line(s) sent doesn't exists!");
                }
            } else {
                writerToClient.println("Login as a passenger first!");
            }

            //REMOVE A SCHEDULE FROM A LINE (ADMIN ONLY)
        } else if (messageFromClient.matches("^line schedule remove ([a-zA-Z_]+)-([a-zA-Z_]+) (\\d\\dh\\d\\d( |$))+")) {
            if (middleNodeInfo.isSuspended) {
                writerToClient.println("The network is suspended! Wait for the unsuspend action");
            } else if (checkSocketPermission(clientSocket) == RoleEnum.ADMIN) {
                String[] lineSplit = messageFromClient.split(" ");
                String lineName = lineSplit[3];
                //if line already exists
                if (!middleNodeInfo.lines.containsKey(lineName)) {
                    writerToClient.println("There isn't a line with that name");
                } else {
                    String[] schedules = Arrays.copyOfRange(lineSplit, 4, lineSplit.length);
                    List<Schedule> scheduleList = createListOfSchedules(schedules);

                    Line tmpLine = this.middleNodeInfo.lines.get(lineName);

                    if (tmpLine.checkSchedulesExists(scheduleList)) {
                        request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.REMOVE_SCHEDULE,
                                new Request.SchedulesInformation(lineName, scheduleList));
                    } else {
                        writerToClient.println("One or more schedule are not associated with that line! Check the existent schedules ");
                    }
                }
            } else {
                writerToClient.println("You don't have permission to execute this command!");
            }

            //SETS A ALTERATION IN LINE (ADMIN/LOCALMANAGERS ONLY)
        } else if (messageFromClient.matches("^alteration (([a-zA-Z_]+)-([a-zA-Z_]+) (\\d\\dh\\d\\d) (\\d\\dh\\d\\d( |$)))+$")) {
            if (middleNodeInfo.isSuspended) {
                writerToClient.println("The network is suspended! Wait for the unsuspend action");
            } else if (checkSocketPermission(clientSocket) != RoleEnum.PASSENGER) {
                String[] linesAlteration = messageFromClient.split(" ");

                //information obj to send to server <lineName, schedule>
                HashMap<Line, List<String>> alterationLines = new HashMap<>();
                boolean error = false;
                //get the lines and schedules sent. i -> line name i+1 -> schedule
                for (int i = 1; i < linesAlteration.length - 2 && !error; i += 3) {
                    //check if line exists
                    if (!this.middleNodeInfo.lines.containsKey(linesAlteration[i])) {
                        error = true;
                        break;
                    } else {
                        Line line = this.middleNodeInfo.lines.get(linesAlteration[i]);
                        //check schedule existence on the line
                        if (!line.getSchedulesListString().contains(linesAlteration[i + 1])) {
                            error = true;
                        } else {
                            alterationLines.put(line, Arrays.asList(linesAlteration[i + 1], linesAlteration[i + 2]));
                        }
                    }
                }
                if (error) {
                    writerToClient.println("You have sent lines or schedules that doesn't exists! Check all the available lines and schedules");
                } else {
                    request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.SCHEDULE_ALTERATION, alterationLines);
                    writerToClient.println("Alteration was sent to the respective passengers!");
                }
            } else {
                writerToClient.println("You don't have permission to execute this command!");
            }

            //SETS ALL NETWORK AS SUSPEND (ADMIN/LOCALMANAGER ONLY)
        } else if (messageFromClient.matches("^suspend$")) {
            //check permission
            if (checkSocketPermission(clientSocket) == RoleEnum.PASSENGER) {
                writerToClient.println("You don't have permission to execute this command!");
            } else if (middleNodeInfo.isSuspended) {
                writerToClient.println("The network is already suspended!");
            } else {
                request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.SUSPENDED_TRAFFIC, null);
            }

            //REMOVES THE SUSPEND STATUS (ADMIN/LOCALMANAGER ONLY)
        } else if (messageFromClient.matches("^unsuspend$")) {
            //check permission
            if (checkSocketPermission(clientSocket) == RoleEnum.PASSENGER) {
                writerToClient.println("You don't have permission to execute this command!");
            } else if (!middleNodeInfo.isSuspended) {
                writerToClient.println("The network is already unsuspended!");
            } else {
                request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.UNSUSPEND_TRAFFIC, null);
            }

            //ADMIN REGISTRATION REQUEST
        } else if (messageFromClient.matches("^admin [a-zA-Z0-9]+@[a-zA-Z0-9]+.[a-zA-Z0-9]+ [a-zA-Z]+ [a-zA-Z0-9!@_-]+ [a-zA-Z0-9]+$")) {
            if (!checkIsLoginIn(clientSocket)) {
                String[] registrationInformation = messageFromClient.split(" ");

                request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.REGISTER_ADMIN,
                        new Request.RegistrationInformationBackOffice(registrationInformation[1], registrationInformation[2], registrationInformation[3], registrationInformation[4]));
            } else {
                writerToClient.println("Logout before make a registration!");
            }

            //LOCALMANAGER REGISTRATION
        } else if (messageFromClient.matches("^localManager [a-zA-Z0-9]+@[a-zA-Z0-9]+.[a-zA-Z0-9]+ [a-zA-Z]+ [a-zA-Z0-9!@_-]+ [a-zA-Z0-9]+$")) {
            if (!checkIsLoginIn(clientSocket)) {
                String[] registrationInformation = messageFromClient.split(" ");

                request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.REGISTER_LOCAL_MANAGER,
                        new Request.RegistrationInformationBackOffice(registrationInformation[1], registrationInformation[2], registrationInformation[3], registrationInformation[4]));
            } else {
                writerToClient.println("Logout before make a registration!");
            }

            //REPORT BY A USER
        } else if (messageFromClient.matches("^report .* .*")) {
            if (middleNodeInfo.isSuspended) {
                writerToClient.println("The network is suspended!");
            } else if (checkIsLoginIn(clientSocket)) {
                String[] reportMessage = messageFromClient.split(" ");
                String comment = "";
                //check if the all lines sent by client exist
                if (this.middleNodeInfo.lines.containsKey(reportMessage[1])) {

                    for (int i = 2; i < reportMessage.length; i++) {
                        comment += reportMessage[i] + " ";
                    }

                    request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.REPORT_FEEDBACK,
                            new Request.WarningInformation(reportMessage[1], comment));
                    writerToClient.println("Your feedback was recorded!");
                } else {
                    writerToClient.println("You have sent a line that doesn't exists! Write lines to see all the available lines");
                }
            } else {
                writerToClient.println("Login before make a report!");
            }

            //LOGOUT REQUEST
        } else if (messageFromClient.matches("^logout")) {
            if (checkIsLoginIn(clientSocket)) {
                logoutClient(clientSocket);

                //get role of client
                RoleEnum role = checkSocketPermission(clientSocket);
                if (checkSocketPermission(clientSocket) != RoleEnum.PASSENGER) {
                    logoutBackOfficeUser(clientSocket, role);
                }
                request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.LOGOUT, role);
                writerToClient.println("Successfully logged out!");
            } else {
                writerToClient.println("You weren't logged in!");
            }
        } else if (messageFromClient.matches("^bye$")) {
            //it's a application close request

            if (checkIsLoginIn(clientSocket)) {
                RoleEnum role = checkSocketPermission(clientSocket);
                request = new Request(socketClient.hashCode(), middleNodeInfo.tcpPort, "server", RequestsEnum.LOGOUT, role);
            }
            writerToClient.println("Thank you for choosing our service!");

        } else {
            writerToClient.println("Bad syntax! Write help to see all the available functionalities");
        }

        return request;
    }

    /**
     * Given a hashcode of a socket returns its role in the system
     */
    private RoleEnum checkSocketPermission(int hashCodeSocket) {
        RoleEnum role = RoleEnum.PASSENGER;
        synchronized (this) {
            if (middleNodeInfo.codeSocketsAdmin.containsKey(hashCodeSocket)) {
                role = RoleEnum.ADMIN;
            } else if (middleNodeInfo.codeSocketsLocalManager.containsKey(hashCodeSocket)) {
                role = RoleEnum.LOCALMANAGER;
            }
        }
        return role;
    }

    /**
     * Execute the logout
     */
    private void logoutBackOfficeUser(int hashCodeSocket, RoleEnum role) {
        synchronized (this) {
            if (role == RoleEnum.ADMIN) {
                middleNodeInfo.codeSocketsAdmin.remove(hashCodeSocket);
            } else {
                middleNodeInfo.codeSocketsLocalManager.remove(hashCodeSocket);
            }
        }
    }

    /**
     * Support function to create a list of schedules given a schedule in string
     */
    private List<Schedule> createListOfSchedules(String[] requestData) {
        List<Schedule> schedulesList = new ArrayList<>();
        for (String schedule : requestData) {
            schedulesList.add(createSchedule(schedule));
        }
        return schedulesList;
    }

    private Schedule createSchedule(String schedule) {
        String[] scheduleSplit = schedule.split("h");
        int hour = Integer.parseInt(scheduleSplit[0]);
        int minutes = Integer.parseInt(scheduleSplit[1]);
        return new Schedule(hour, minutes);
    }


    private boolean checkIsLoginIn(int hashCodeSocket) {
        synchronized (middleNodeInfo.onlineClients) {
            return middleNodeInfo.onlineClients.containsKey(hashCodeSocket);
        }
    }

    private void logoutClient(int hashCodeSocket) {
        synchronized (middleNodeInfo.onlineClients) {
            middleNodeInfo.onlineClients.remove(hashCodeSocket);
        }
    }

    /**
     * Prints all lines to the client
     */
    private void printLinesToClient(PrintWriter writer) {
        StringBuilder stringBuilder = new StringBuilder();

        if (middleNodeInfo.lines.size() == 0) {
            stringBuilder.append("There is no lines at the moment");
        } else {
            int count = 0;
            for (Line line : middleNodeInfo.getLines().values()) {
                count++;
                if (count > 5) {
                    stringBuilder.append("\n");
                    count = 0;
                }
                stringBuilder.append(line.getName() + "     ");
            }
        }
        writer.println(stringBuilder);
    }

    /**
     * Print all schedules
     */
    private void printSchedulesToClient(PrintWriter writer, String message) {
        String[] split = message.split(" ");

        if (split.length < 2) {
            writer.println("Bad syntax! You should specify the lines");
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            //for each line sent
            for (int i = 1; i < split.length; i++) {
                if (this.middleNodeInfo.lines.containsKey(split[i])) {
                    Line tmpLine = this.middleNodeInfo.lines.get(split[i]);
                    stringBuilder.append(tmpLine.getName() + "\n");
                    stringBuilder.append(tmpLine.getSchedulesString());
                } else {
                    stringBuilder.append("The line '" + split[i] + "' doesn't exist!");
                }
                stringBuilder.append("\n");
            }
            writer.println(stringBuilder);
        }
    }

    /**
     * Print the lines of the client that is connected
     */
    private void printClientLines(PrintWriter writer) {
        if (checkSocketPermission(this.socketClient.hashCode()) != RoleEnum.PASSENGER) {
            writer.println("Your account should correspond to a passenger!");
        } else if (!checkIsLoginIn(this.socketClient.hashCode())) {
            writer.println("Login with your account first!");
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            for (Line line : middleNodeInfo.clientsPerLine.keySet()) {
                if (middleNodeInfo.clientsPerLine.get(line).contains(this.socketClient)) {
                    stringBuilder.append(line.getName() + " ");
                }
            }
            writer.println("-------------------- Associated lines --------------------");
            writer.println(stringBuilder);
        }
    }
}
