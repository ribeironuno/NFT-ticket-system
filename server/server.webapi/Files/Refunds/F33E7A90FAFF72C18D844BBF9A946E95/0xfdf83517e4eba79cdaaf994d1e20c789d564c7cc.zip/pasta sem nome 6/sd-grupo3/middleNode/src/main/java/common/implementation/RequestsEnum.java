package common.implementation;

/*
   LOGIN -> Request login using the email and password sent in the registration request
   REGISTRATION -> Registration on the system by using the email and password
   WARNING_LINE -> The ordinary passenger can report a change of the schedule
   SUSPENDED_TRAFFIC -> A special passenger can report suspend traffic warning, that is sent in broadcast
   SCHEDULE_ALTERATION -> A special passenger can report alteration schedule in on or more lines
 */
public enum RequestsEnum {
    NEW_CONNECTION, LOGIN, REGISTRATION, LOGOUT, REPORT_FEEDBACK, SUSPENDED_TRAFFIC, SCHEDULE_ALTERATION, REGISTER_ADMIN, REGISTER_LOCAL_MANAGER,
    ADD_LINE, REMOVE_LINE, ADD_SCHEDULE, REMOVE_SCHEDULE, UNSUSPEND_TRAFFIC, ASSOCIATE_LINE, DISSOCIATE_LINE, EXIT
}
