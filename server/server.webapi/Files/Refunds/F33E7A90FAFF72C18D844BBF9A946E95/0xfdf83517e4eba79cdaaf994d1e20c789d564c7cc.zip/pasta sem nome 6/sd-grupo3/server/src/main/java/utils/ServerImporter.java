package utils;

import centralnode.implementation.ServerInformation;
import centralnode.model.User;
import common.implementation.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Class responsible to import the information about the server
 */
public class ServerImporter implements IServerImporter {

    @Override
    public ServerInformation importServiceSettings(String directoryFile) throws IOException, ParseException {

        //prepare to read the file
        JSONParser parser = new JSONParser();
        Reader reader = new FileReader(directoryFile);
        JSONObject obj = (JSONObject) parser.parse(reader);

        //start reading the file
        int serverPort = (int) ((long) obj.get("serverPort"));
        String host = (String) obj.get("host");
        int gatewayPort = (int) ((long) obj.get("gatewayPort"));
        String secretAdmin = (String) obj.get("secretAdmin");
        String secretLocalManager = (String) obj.get("secretLocalManager");

        //create the final object
        ServerInformation serverInformation = new ServerInformation(serverPort, host, gatewayPort, secretAdmin, secretLocalManager);
        return serverInformation;
    }

    @Override
    public HashMap<String, User> importUsersInformation(String directoryFile) throws IOException, ParseException {

        //prepare to read the file
        JSONParser parser = new JSONParser();
        Reader reader = new FileReader(directoryFile);
        JSONArray users = (JSONArray) parser.parse(reader);

        HashMap<String, User> usersInformation = new HashMap<>();

        for (Object user : users) {
            JSONObject obj = (JSONObject) user; //Get user in array

            String email = (String) obj.get("email");
            String password = (String) obj.get("password");
            String name = (String) obj.get("name");
            String role = (String) obj.get("role");

            if (role.equals(RoleEnum.PASSENGER.toString())) {
                JSONArray lines = (JSONArray) obj.get("lines");
                List<String> linesArray = new ArrayList<>();

                for (int i = 0; i < lines.size(); i++) {
                    String line = (String) lines.get(i);
                    linesArray.add(line);
                }
                usersInformation.put(email, new User(email, password, name, linesArray));
            } else if (role.equals(RoleEnum.ADMIN.toString())) {
                usersInformation.put(email, new User(email, password, name, RoleEnum.ADMIN));
            } else {
                usersInformation.put(email, new User(email, password, name, RoleEnum.LOCALMANAGER));
            }
        }

        return usersInformation;
    }

    @Override
    public HashMap<String, Line> importLinesInformation(String directoryFile) throws IOException, ParseException {

        //prepare to read the file
        JSONParser parser = new JSONParser();
        Reader reader = new FileReader(directoryFile);
        JSONArray lines = (JSONArray) parser.parse(reader);

        HashMap<String, Line> linesInformation = new HashMap();

        for (Object line : lines) {
            JSONObject obj = (JSONObject) line; //Get lines in array

            String lineName = (String) obj.get("name");
            JSONArray schedulesArray = (JSONArray) obj.get("schedules");

            Line lineObj = new Line(lineName);

            for (int i = 0; i < schedulesArray.size(); i++) {
                String scheduleString = (String) schedulesArray.get(i);
                if (scheduleString.matches("^\\d\\dh\\d\\d$")) {
                    String[] split = scheduleString.split("h");
                    Schedule schedule = new Schedule(Integer.parseInt(split[0]), Integer.parseInt(split[1]));
                    lineObj.addSchedule(schedule);
                }
            }

            linesInformation.put(lineObj.getName(), lineObj);
        }
        return linesInformation;
    }
}
