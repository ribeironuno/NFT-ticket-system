package middlenode;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class MiddleSyncClockThread extends Thread {

    private int syncPort;
    private String host;
    private DatagramSocket socket;
    private InetAddress serverAddress;

    public MiddleSyncClockThread(int syncPort, String host, DatagramSocket socket, InetAddress serverAddress) {
        this.syncPort = syncPort;
        this.host = host;
        this.socket = socket;
        this.serverAddress = serverAddress;
    }

    @Override
    public void run() {
        // send packet to server
        byte[] sendData;
        byte[] receiveData = new byte[1024];

        while (true) {
            try {
                // send current time to server
                long currentTime = System.currentTimeMillis();
                sendData = ByteBuffer.allocate(8).putLong(currentTime).array();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, syncPort);
                socket.send(sendPacket);

                // receive current time and clock offset from server
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);
                long serverTime = ByteBuffer.wrap(receivePacket.getData()).getLong();

                // adjust local clock
                long localTime = serverTime;
                System.out.println("Clock synchronized!");

                // wait for next synchronization
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    // handle exception
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
